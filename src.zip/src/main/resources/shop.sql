/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 5.5.62 : Database - shop
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`shop` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `shop`;

/*Table structure for table `account` */

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(20) DEFAULT NULL,
  `USER_TYPE` int(20) DEFAULT NULL,
  `ACCOUNT_NUM` int(20) DEFAULT NULL,
  `IFSC` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `BANK_NAME` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `NAME` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `CARD_NUM` int(16) DEFAULT NULL,
  `CARD_TYPE` int(10) DEFAULT NULL,
  `EXPIRY_DATE` date DEFAULT NULL,
  `CURRENCY` int(11) DEFAULT NULL,
  `DATE` date DEFAULT NULL,
  `AMOUNT` float DEFAULT NULL,
  `MOBILE_NUMBER` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `account` */

insert  into `account`(`ID`,`USER_ID`,`USER_TYPE`,`ACCOUNT_NUM`,`IFSC`,`BANK_NAME`,`NAME`,`CARD_NUM`,`CARD_TYPE`,`EXPIRY_DATE`,`CURRENCY`,`DATE`,`AMOUNT`,`MOBILE_NUMBER`,`SHOP_ID`,`IS_DELETED`,`IS_ACTIVE`) values 
(1,30,222,444,'rohan343','BOB','Bholu',2323,232323,'2021-04-06',332,'2021-04-06',2323420,'454545','Avi23',0,0),
(2,30,33,21233333,'rohan343','BOB','Bholu',2323,232323,'2021-03-05',332,'2021-03-10',2323420,'77332255','jh77',0,1),
(3,30,0,444,'rohan343','BOB','Bholu',2323,232323,NULL,332,NULL,2323420,'454545','jh77',0,0),
(4,30,0,444,'rohan343','BOB','Bholu',2323,232323,'2021-04-06',332,'2021-04-06',2323420,'454545','jh87',0,0),
(5,30,222,21233333,'avinash343','BOB','Bholu',2323,232323,'2021-03-24',332,'2021-03-24',2323420,'77332255',NULL,0,0),
(6,30,222,21233333,'rohan343','BOB','Bholu',2323,232323,'2025-04-01',332,'2021-03-24',2323420,'77332255',NULL,0,0);

/*Table structure for table `account_transaction` */

DROP TABLE IF EXISTS `account_transaction`;

CREATE TABLE `account_transaction` (
  `ID` int(11) NOT NULL,
  `DEBIT_FROM` int(11) NOT NULL,
  `CREDIT_TO` int(11) NOT NULL,
  `AMOUNT` int(11) NOT NULL,
  `REMARKS` varchar(200) NOT NULL,
  `STATUS` tinyint(1) NOT NULL,
  `DATE` int(11) NOT NULL,
  `CURRENCY` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `account_transaction` */

/*Table structure for table `address` */

DROP TABLE IF EXISTS `address`;

CREATE TABLE `address` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PIN_CODE` int(20) DEFAULT NULL,
  `CITY` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `STATE` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `COUNTRY` varchar(100) COLLATE utf8_bin NOT NULL,
  `LONGITUDE` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `LATITUDE` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `MOBILE_NUMBER` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `LAND_MARK` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `USER_ID` int(7) NOT NULL,
  `USER_TYPE` int(3) NOT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `CREATED_ON` date DEFAULT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `DISTRICT` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `POST_OFFICE` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `POLICE_STATION` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `ADMIN_ID` int(5) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `address` */

insert  into `address`(`ID`,`PIN_CODE`,`CITY`,`STATE`,`COUNTRY`,`LONGITUDE`,`LATITUDE`,`MOBILE_NUMBER`,`LAND_MARK`,`USER_ID`,`USER_TYPE`,`SHOP_ID`,`CREATED_ON`,`IS_DELETED`,`IS_ACTIVE`,`DISTRICT`,`POST_OFFICE`,`POLICE_STATION`,`ADMIN_ID`) values 
(1,123456,'Patna','Bihar','India','123.456','235.145','1236547890','Temple',1,2,'Avi23','2021-04-15',0,1,'Patna','Patna','Patna',1),
(4,334444,'patna','bihar','India','34','45','44334433','Temple',5,4,'pri23','2021-04-10',0,1,'Patna','Patna','Patna',2);

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `EMAIL_ID` varchar(100) COLLATE utf8_bin NOT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `F_NAME` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `L_NAME` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `USER_TYPE` int(11) NOT NULL,
  `TOKEN` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `AVATAR` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `ADHAR_NUM` int(13) NOT NULL DEFAULT '0',
  `ADHAR_AVATAR` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `PAN_NUM` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  `PAN_AVATAR` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `MOBILE_NUMBER` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `CREATED_ON` date DEFAULT NULL,
  `PWD` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `DEBIT` float DEFAULT NULL,
  `CREDIT` float DEFAULT NULL,
  `PAYMENT_STATUS` tinyint(1) DEFAULT NULL,
  `SHOP_NAME` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `SHOP_TYPE` int(6) DEFAULT NULL,
  `VALIDITY` int(2) NOT NULL,
  `WALLET` float DEFAULT NULL,
  `IS_ACTIVE` tinyint(1) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `LAST_LOGIN_DATE` date DEFAULT NULL,
  `OTP` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `GST_NUMBER` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `admin` */

insert  into `admin`(`ID`,`EMAIL_ID`,`SHOP_ID`,`F_NAME`,`L_NAME`,`USER_TYPE`,`TOKEN`,`AVATAR`,`ADHAR_NUM`,`ADHAR_AVATAR`,`PAN_NUM`,`PAN_AVATAR`,`MOBILE_NUMBER`,`CREATED_ON`,`PWD`,`DEBIT`,`CREDIT`,`PAYMENT_STATUS`,`SHOP_NAME`,`SHOP_TYPE`,`VALIDITY`,`WALLET`,`IS_ACTIVE`,`IS_DELETED`,`LAST_LOGIN_DATE`,`OTP`,`GST_NUMBER`) values 
(1,'admin214573@milaan.com','Avi23',NULL,NULL,1,'fa8fe996-6fb0-4dbc-a9a4-e78910b16f64-1',NULL,122,NULL,NULL,NULL,NULL,NULL,'Milaan',0,0,1,NULL,0,31,0,1,0,'2021-04-16','334','45645645'),
(2,'pri@34','pri23',NULL,NULL,1,'345rtr',NULL,45,NULL,NULL,NULL,NULL,NULL,'Milaan',0,0,1,NULL,1,29,0,0,0,'2021-04-11','3432','4564545');

/*Table structure for table `admin_device_id_mapping` */

DROP TABLE IF EXISTS `admin_device_id_mapping`;

CREATE TABLE `admin_device_id_mapping` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `ADMIN_ID` int(10) NOT NULL,
  `DEVICE_ID` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `APNS_TOKEN_ID` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `admin_device_id_mapping` */

insert  into `admin_device_id_mapping`(`ID`,`ADMIN_ID`,`DEVICE_ID`,`APNS_TOKEN_ID`) values 
(1,1,'4345-tr45-23ytr-34ytre-54ttt','55555'),
(2,2,'44444444','ttttt444'),
(3,0,NULL,NULL),
(4,26,'qwerty1234asdf12',NULL),
(5,1,'4345-tr45-23ytr-34ytre-5422w',NULL),
(6,51,'abc12-def34-ghi56',NULL),
(7,1,'1231gdfgdfgdfh3452453',NULL),
(8,1,'9942453d797eb694',NULL),
(9,1,'d08201b10eb9ecd5',NULL);

/*Table structure for table `article` */

DROP TABLE IF EXISTS `article`;

CREATE TABLE `article` (
  `article_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Title` varchar(200) CHARACTER SET latin1 NOT NULL,
  `Teaser` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `body_content` text CHARACTER SET latin1,
  `MO_ID` int(11) DEFAULT NULL,
  `Article_Type` int(11) DEFAULT NULL,
  `Publish_Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `article` */

insert  into `article`(`article_id`,`Title`,`Teaser`,`body_content`,`MO_ID`,`Article_Type`,`Publish_Status`) values 
(1,'Full Name','name ask','What is your full name?',0,37,0),
(2,'Age','age ask','What is your age?',0,37,0),
(3,'Full Address','address','What is your full address?',0,37,0),
(4,'This is React Native Intro Project','Impulse Season 2: From the director of The Bourne Identity and Edge of Tomorrow','addd',31,35,0),
(5,'This is Native script Intro Project','Impulse Season 2: From the director of The Bourne Identity and Edge of Tomorrow',NULL,32,35,0),
(6,'My name is Avinash, work on UI Technologies for web and mobile','What is Spring Boot CLI?Spring Boot CLI(Command Line Interface) is a Spring Boot software to run and test Spring Boot applications from command prompt. When we run Spring Boot applications using CLI',NULL,35,35,0),
(7,'My name is Avinash, work on UI Technologies for web and mobile','What is Spring Boot CLI?Spring Boot CLI(Command Line Interface) is a Spring Boot software to run and test Spring Boot applications from command prompt. When we run Spring Boot it internally',NULL,40,35,0);

/*Table structure for table `articlefile` */

DROP TABLE IF EXISTS `articlefile`;

CREATE TABLE `articlefile` (
  `ArticleFileId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fileName` varchar(200) NOT NULL,
  `fileDescription` varchar(200) DEFAULT NULL,
  `fileType` varchar(45) DEFAULT NULL,
  `fileSize` int(11) DEFAULT NULL,
  `domain` varchar(45) DEFAULT NULL,
  `filePath` varchar(250) DEFAULT NULL,
  `fileUrl` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ArticleFileId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `articlefile` */

insert  into `articlefile`(`ArticleFileId`,`fileName`,`fileDescription`,`fileType`,`fileSize`,`domain`,`filePath`,`fileUrl`) values 
(1,'abc.pdf','pdf file','pdf',100,'tech','C://abc.pdf',NULL);

/*Table structure for table `attendance` */

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `EMPLOYEE_ID` varchar(22) COLLATE utf8_bin DEFAULT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `CREATED_ON` date DEFAULT NULL,
  `ATTENDANCE` int(2) DEFAULT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `attendance` */

insert  into `attendance`(`ID`,`EMPLOYEE_ID`,`SHOP_ID`,`CREATED_ON`,`ATTENDANCE`,`IS_ACTIVE`,`IS_DELETED`) values 
(1,'raju34','Avi23','2021-03-26',2,1,0),
(2,'ff','Avi23','2021-03-26',3,1,0),
(3,'ramu56','shop121',NULL,0,1,0),
(4,'sohan34','shop121',NULL,40,1,0),
(5,'rohan43','jayram',NULL,2,1,0);

/*Table structure for table `bank` */

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACCOUNT_NUM` int(30) NOT NULL,
  `BANK_NAME` varchar(100) NOT NULL,
  `NAME` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ADDRESS` varchar(200) NOT NULL,
  `IFSC` varchar(100) NOT NULL,
  `SHOP_ID` varchar(50) DEFAULT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `bank` */

insert  into `bank`(`ID`,`ACCOUNT_NUM`,`BANK_NAME`,`NAME`,`ADDRESS`,`IFSC`,`SHOP_ID`,`IS_ACTIVE`,`IS_DELETED`) values 
(1,435345345,'fgfghfg','mohan','dfgdf','234frgr','Avi23',1,0),
(2,345345345,'SBI','sohan','muz','342ff','gg',1,0),
(3,334,'fgfghfg','rohan','dfgdf','234frgr','vbn66',1,0),
(4,4354444,'fgfghfg','rohan','dfgdf','234frgr','fgh656',1,0),
(5,435345345,'SBI','mohan','muzaffarpur','234frgr','yy66',1,0),
(6,34534,'SBI','radha','patna','sdfdsf34234','pri34',0,0);

/*Table structure for table `brand` */

DROP TABLE IF EXISTS `brand`;

CREATE TABLE `brand` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AVATAR` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `TITLE` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `NAME` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `CATEGORY` int(11) NOT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `brand` */

insert  into `brand`(`ID`,`AVATAR`,`TITLE`,`NAME`,`SHOP_ID`,`CATEGORY`,`IS_ACTIVE`,`IS_DELETED`) values 
(1,NULL,'SAMSUNG','Samsun','123as',1,1,0);

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `CREATED_ON` date DEFAULT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin NOT NULL,
  `GST_AMOUNT` float NOT NULL DEFAULT '0',
  `TOTAL_AMOUNT` float NOT NULL,
  `TRANSACTION_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `PAID` float NOT NULL,
  `DUES` float NOT NULL,
  `IS_ACTIVE` tinyint(1) DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  `USER_ID` int(50) NOT NULL,
  `ORDER` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `cart` */

insert  into `cart`(`ID`,`CREATED_ON`,`SHOP_ID`,`GST_AMOUNT`,`TOTAL_AMOUNT`,`TRANSACTION_ID`,`PAID`,`DUES`,`IS_ACTIVE`,`IS_DELETED`,`USER_ID`,`ORDER`) values 
(1,'2021-04-14','Avi23',45,5645,'4',11,344,1,0,1,1),
(2,'2021-03-09','Avi23',54,4566,'3',22,54,1,0,2,1),
(3,'2021-03-09','shavam23',55,566,'23',3,43,1,0,2,1),
(4,NULL,'shavam34',45,56456,'2',334,34,1,0,3,1),
(5,NULL,'mohN11',78,5664,'1',44,34,1,0,4,1),
(6,'2021-04-05','',455,43534,'44',55,454,1,0,5,1),
(7,'2021-04-14','Avi23',45,5645,'4',661,344,0,0,6,1);

/*Table structure for table `casual_leave` */

DROP TABLE IF EXISTS `casual_leave`;

CREATE TABLE `casual_leave` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `LEAVE_FROM` date DEFAULT NULL,
  `LEAVE_TO` date DEFAULT NULL,
  `REASION` varchar(400) COLLATE utf8_bin DEFAULT NULL,
  `EMPLOYEE_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `LEAVE_TYPE` int(30) DEFAULT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `casual_leave` */

insert  into `casual_leave`(`ID`,`LEAVE_FROM`,`LEAVE_TO`,`REASION`,`EMPLOYEE_ID`,`SHOP_ID`,`LEAVE_TYPE`,`IS_ACTIVE`,`IS_DELETED`) values 
(1,'2021-03-18','2021-03-23','meeting','shu123','Avi23',11,0,0),
(2,'2021-03-26','2021-03-27','meeting','shu123','Avi23',11,1,0),
(6,NULL,NULL,NULL,'shu1232','shu12355',NULL,0,0),
(7,'2021-04-05','2021-04-05','meeting','shu111','shop',11,0,0),
(8,'2021-04-05','2021-04-05','meeting','shu222','shop',11,0,0),
(9,'2021-04-05','2021-04-05','meeting','shu444','electronic',11,0,0),
(10,'2021-04-01','2021-04-01','meeting','shu555','shop333',NULL,0,0),
(11,'2021-04-01','2021-04-01','meeting','shu666','shop333',23,0,0);

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `NAME` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `AVATAR` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `category` */

insert  into `category`(`ID`,`TITLE`,`NAME`,`AVATAR`,`SHOP_ID`,`IS_ACTIVE`,`IS_DELETED`) values 
(1,NULL,'Avinash Kumar','moh123','Avi23',1,0),
(2,NULL,'rohan','rohan33','Avi23',1,0),
(3,NULL,'Avinash Kumar',NULL,'pri23',1,0),
(4,NULL,'sunny Kumar',NULL,'pri23',1,0);

/*Table structure for table `comments` */

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `COMMENTS_ID` int(11) NOT NULL AUTO_INCREMENT,
  `TOPICS_ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `CREATED_ON` date NOT NULL,
  `COMMENTS_TEXT` text COLLATE utf8_bin NOT NULL,
  `COMMENTS_TYPE` int(11) NOT NULL,
  PRIMARY KEY (`COMMENTS_ID`),
  KEY `TOPICS_REF` (`TOPICS_ID`),
  CONSTRAINT `TOPICS_REF` FOREIGN KEY (`TOPICS_ID`) REFERENCES `topics` (`TOPICS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `comments` */

/*Table structure for table `consultation_workflow` */

DROP TABLE IF EXISTS `consultation_workflow`;

CREATE TABLE `consultation_workflow` (
  `CONSULTATION_WORKFLOW_ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `CONSULTANT_ID` int(11) NOT NULL,
  `ARTICLE_ID` int(11) DEFAULT NULL,
  `PRICE` int(11) DEFAULT NULL,
  `STATUS` tinyint(1) DEFAULT NULL,
  `REASON_FOR_REJECT` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `CREATEDATE` datetime DEFAULT NULL,
  `FINISHEDATE` datetime DEFAULT NULL,
  `RATING` int(11) DEFAULT NULL,
  `FEEDBACK` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`CONSULTATION_WORKFLOW_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `consultation_workflow` */

insert  into `consultation_workflow`(`CONSULTATION_WORKFLOW_ID`,`USER_ID`,`CONSULTANT_ID`,`ARTICLE_ID`,`PRICE`,`STATUS`,`REASON_FOR_REJECT`,`CREATEDATE`,`FINISHEDATE`,`RATING`,`FEEDBACK`) values 
(1,2,3,NULL,6,1,NULL,NULL,NULL,0,NULL),
(3,2,7,NULL,5,1,NULL,NULL,NULL,0,NULL),
(4,2,1,NULL,5,1,NULL,NULL,NULL,0,NULL),
(5,2,4,NULL,12,1,NULL,NULL,NULL,0,NULL),
(6,22,4,NULL,12,1,NULL,NULL,NULL,0,NULL);

/*Table structure for table `employee` */

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `F_NAME` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `L_NAME` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `FATHER` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `SHOP_ID` varchar(10) COLLATE utf8_bin NOT NULL,
  `ADHAR_NUM` int(12) DEFAULT NULL,
  `ADHAR_AVATAR` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `PAN_NUM` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `PAN_AVATAR` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `SALARY` float DEFAULT NULL,
  `SALARY_TYPE` int(20) DEFAULT NULL,
  `JOINING_DATE` date DEFAULT NULL,
  `VILLAGE` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `POLICE_STATION` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `POST_OFFICE` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `DISTRICT` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `PIN_CODE` int(6) DEFAULT NULL,
  `WORKING_DAYS` int(2) DEFAULT NULL,
  `DESIGNATION` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `EMPLOYEE_ID` varchar(10) COLLATE utf8_bin NOT NULL,
  `MOBILE_NUMBER` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `EMAIL_ID` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `CREATED_ON` date DEFAULT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `STREET` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `LAND_MARK` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `STATE` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `employee` */

insert  into `employee`(`ID`,`F_NAME`,`L_NAME`,`FATHER`,`SHOP_ID`,`ADHAR_NUM`,`ADHAR_AVATAR`,`PAN_NUM`,`PAN_AVATAR`,`SALARY`,`SALARY_TYPE`,`JOINING_DATE`,`VILLAGE`,`POLICE_STATION`,`POST_OFFICE`,`DISTRICT`,`PIN_CODE`,`WORKING_DAYS`,`DESIGNATION`,`EMPLOYEE_ID`,`MOBILE_NUMBER`,`EMAIL_ID`,`CREATED_ON`,`IS_DELETED`,`IS_ACTIVE`,`STREET`,`LAND_MARK`,`STATE`) values 
(1,'aniket','Kumar','rohan','Avi23',123456789,'qwerty','qwer124zx','asdf123',123,1,'2010-01-12','qwe','zxc','asdf','qwet',122345,12,'post','hghh123','1267543789','pri@21','2010-01-12',0,1,'ram','bazar','bihar'),
(2,'Prince','kumar','DFGDSFGFDS','Avi23',123456789,'dsferf','ewrweew','23erwfer',43334,33,'2021-03-12','erwfe','werter','erterete','reer',123456,11,'rere','23ewr','23453434','raj@21','2021-03-12',0,1,'mohan','bazar','bihar'),
(3,NULL,NULL,NULL,'Avi23',0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'Avinash123','0',NULL,NULL,0,1,NULL,NULL,NULL),
(4,'prince','Kumar','rohan','prince12',123456789,'adharAvtar','pan124zx','panAvatar123',14000,1,NULL,'muzaffarpur','muz','saraiya','muzaffarpur',844111,12,'post','Pk12377','1267543789','sonu@21',NULL,0,1,'ram','bazar','bihar'),
(5,'prince','Kumar','rohan','prince12',123456789,'adharAvtar','pan124zx','panAvatar123',14000,1,NULL,'muzaffarpur','muz','saraiya','muzaffarpur',844111,12,'post','Pk12377','1267543789','ritu@21',NULL,0,1,'ram','bazar','bihar'),
(6,NULL,NULL,NULL,'1234asdf',0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'hghh1','0',NULL,NULL,0,1,NULL,NULL,NULL);

/*Table structure for table `hashtag` */

DROP TABLE IF EXISTS `hashtag`;

CREATE TABLE `hashtag` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CATAGORY_ID` int(2) NOT NULL,
  `TAG_TEXT` varchar(200) COLLATE utf8_bin NOT NULL,
  `CREATED_ON` date NOT NULL,
  `USER_ID` int(5) NOT NULL,
  `DESCRIPTION` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `IS_DELETED` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `hashtag` */

insert  into `hashtag`(`ID`,`CATAGORY_ID`,`TAG_TEXT`,`CREATED_ON`,`USER_ID`,`DESCRIPTION`,`IS_DELETED`) values 
(1,13,'CMS','2020-10-20',1,'CMS',0),
(2,13,'ECM','2020-10-20',1,'CMS',0),
(3,13,'WCM','2020-10-19',1,'CMS',0),
(4,13,'WCM','2020-10-19',1,'AEM CONTENT CMS HASHTAG',0);

/*Table structure for table `job` */

DROP TABLE IF EXISTS `job`;

CREATE TABLE `job` (
  `POST_ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `POST_CATEGORY` int(11) NOT NULL,
  `ARTICLE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) DEFAULT NULL,
  `BUDGET` int(11) DEFAULT NULL,
  `CURRENCY` int(11) NOT NULL,
  PRIMARY KEY (`POST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `job` */

/*Table structure for table `job_application` */

DROP TABLE IF EXISTS `job_application`;

CREATE TABLE `job_application` (
  `ID` int(11) NOT NULL,
  `JOB_ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `APPL_DATE` int(11) NOT NULL,
  `PROPOSE_PRICE` int(11) NOT NULL,
  `ARTICLE` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `job_application` */

/*Table structure for table `lookup` */

DROP TABLE IF EXISTS `lookup`;

CREATE TABLE `lookup` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LOOKUP_NAME` varchar(100) COLLATE utf8_bin NOT NULL,
  `LOOKUP_LABEL` varchar(500) COLLATE utf8_bin NOT NULL,
  `LOOKUP_TYPE_ID` int(10) NOT NULL,
  `SHOP_ID` varchar(60) COLLATE utf8_bin NOT NULL,
  `IS_DELETED` tinyint(1) NOT NULL DEFAULT '0',
  `IS_ACTIVE` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `lookup` */

insert  into `lookup`(`ID`,`LOOKUP_NAME`,`LOOKUP_LABEL`,`LOOKUP_TYPE_ID`,`SHOP_ID`,`IS_DELETED`,`IS_ACTIVE`) values 
(1,'ADMIN','ADMIN',1,'MILAAN',0,1),
(2,'CUSTOMER','CUSTOMER',1,'MILAAN',0,1),
(3,'EMPLOYEE','EMPLOYEE',1,'MILAAN',0,1),
(4,'MEDICAL','MEDICAL',2,'MILAAN',0,1),
(5,'FURNITURE','FURNITURE',2,'MILAAN',0,1),
(6,'GROCERY','GROCERY',2,'MILAAN',0,1),
(7,'JEWELLERY','JEWELLERY',2,'MILAAN',0,1),
(8,'BOOK_SHOP','BOOK SHOP',2,'MILAAN',0,1),
(9,'ELECTRONIC','ELECTRONIC',2,'MILAAN',0,1),
(10,'GARMENT_SHOP','GARMENT SHOP',2,'MILAAN',0,1),
(11,'COSTMETIC','COSTMETIC',2,'MILAAN',0,1),
(12,'HARDWARE','HARDWARE',2,'MILAAN',0,1),
(13,'CASH','CASH',3,'MILAAN',0,1),
(14,'ONLINE_PAYMENT','ONLINE PAYMENT',3,'MILAAN',0,1),
(15,'PCS','PCS',4,'MILAAN',0,1),
(16,'KG','KG',4,'MILAAN',0,1),
(17,'GM','GM',4,'MILAAN',0,1),
(18,'LITER','LITER',4,'MILAAN',0,1),
(19,'METER','METER',4,'MILAAN',0,1),
(20,'ADIDAS','ADIDAS',5,'MILAAN',0,1),
(21,'SONY','SONY',5,'MILAAN',0,1),
(22,'HP','HP',5,'MILAAN',0,1),
(23,'PATANJALI','PATANJALI',5,'MILAAN',0,1),
(24,'TRAVEL/TOURISM','السفر',12,'MILAAN',0,1),
(25,'OTHERS','الآخرين',12,'MILAAN',0,1),
(26,'SAR','SAR',2,'MILAAN',0,1),
(27,'ADMIN','ADMIN',5,'MILAAN',0,1),
(28,'CONSULTANT','CONSULTANT',5,'MILAAN',0,1),
(29,'USER','USER',5,'MILAAN',0,1),
(30,'ERP CONSULTANT','ERP CONSULTANT',13,'MILAAN',0,1),
(31,'CLOUD ARCHITECT','CLOUD ARCHITECT',13,'MILAAN',0,1),
(32,'DATA ANALYST','DATA ANALYST',13,'MILAAN',0,1),
(33,'ALL','ALL',12,'MILAAN',0,1),
(34,'NOTIFICATION','NOTIFICATION',6,'MILAAN',0,1),
(35,'PROFILE','PROFILE',6,'MILAAN',0,1),
(36,'FEEDBACK','FEEDBACK',6,'MILAAN',0,1),
(37,'POST','POST',6,'MILAAN',0,1),
(38,'BLOG','BLOG',6,'MILAAN',0,1),
(39,'WEBPAGE','WEBPAGE',6,'MILAAN',0,1),
(43,'AVAILABLE','AVAILABLE',8,'MILAAN',0,1),
(44,'UNAVAILABLE','UNAVAILABLE',8,'MILAAN',0,1),
(45,'AVAILABLE BUT CAN\'T ANSWER','AVAILABLE BUT CAN\'T ANSWER',8,'MILAAN',0,1),
(46,'ENGLISH','ENGLISH',7,'MILAAN',0,1),
(47,'ARABIC','ARABIC',7,'MILAAN',0,1),
(48,'FRENCH','FRENCH',7,'MILAAN',0,1),
(49,'UNREAD','UNREAD',9,'MILAAN',0,1),
(50,'READ','READ',9,'MILAAN',0,1),
(51,'DELIVERED','DELIVERED',9,'MILAAN',0,1),
(52,'DELETED','DELETED',9,'MILAAN',0,1),
(53,'FREE','FREE AVAILABILITY ',8,'MILAAN',0,1),
(54,'TEXT','TEXT',10,'MILAAN',0,1),
(55,'AUDIO','AUDIO',10,'MILAAN',0,1),
(56,'VIDEO','VIDEO',10,'MILAAN',0,1),
(57,'QUESTION','QUESTION',10,'MILAAN',0,1),
(58,'IMAGE','IMAGE',10,'MILAAN',0,1),
(59,'QUE_ANS','QUE_ANS',10,'MILAAN',0,1),
(60,'MyList','MyList',12,'MILAAN',0,1);

/*Table structure for table `lookup_type` */

DROP TABLE IF EXISTS `lookup_type`;

CREATE TABLE `lookup_type` (
  `ID` int(20) NOT NULL AUTO_INCREMENT,
  `LOOKUP_TYPE_NAME` varchar(20) COLLATE utf8_bin NOT NULL,
  `LOOKUP_TYPE_LABEL` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `lookup_type` */

insert  into `lookup_type`(`ID`,`LOOKUP_TYPE_NAME`,`LOOKUP_TYPE_LABEL`) values 
(1,'USER_TYPE','USER_TYPE'),
(2,'SHOP_TYPE','SHOP TYPE'),
(3,'PAYMENT_MODE','PAYMENT MODE'),
(4,'MEASURMENT_TYPE','MEASURMENT TYPE'),
(5,'BRAND','BRAND'),
(6,'AVAILABILITY','AVAILABILITY'),
(7,'NOTIFICATION_STATUS','NOTIFICATION_STATUS'),
(8,'CATEGORY','CATEGORY');

/*Table structure for table `managedobject` */

DROP TABLE IF EXISTS `managedobject`;

CREATE TABLE `managedobject` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(40) COLLATE utf8_bin NOT NULL,
  `object_type` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_date` date DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `managedobject` */

insert  into `managedobject`(`ID`,`guid`,`object_type`,`created_date`,`created_by`,`modified_date`,`modified_by`) values 
(3,'cf13c823-1620-4ce2-bf09-6543dfdc7c48',1,'2019-09-08',0,NULL,0),
(4,'5ad923b5-911c-42d2-ac2a-eb65bfe1c65f',1,'2019-09-08',10,NULL,0),
(5,'18d17946-40d6-4292-bd6b-80752c652b64',1,'2019-09-08',10,NULL,0),
(6,'352dba05-2520-4d59-90c5-31392e45b064',1,'2019-09-08',10,NULL,0),
(7,'3c1d7cc1-aa58-42fe-9be2-16c8e5838057',1,'2019-09-12',10,NULL,0),
(8,'5337a632-264c-46ea-b691-362f7c05f03a',1,'2019-09-12',10,NULL,0),
(9,'4b710113-9834-4ffe-ab7a-2459baacab6a',1,'2019-09-12',10,NULL,0),
(10,'d8457444-302c-4698-97ea-ebabf9483317',1,'2019-10-26',10,NULL,0),
(12,'eb228160-6ac2-4ec6-97af-73f42a7cac63',1,'2019-10-27',10,NULL,0),
(13,'befbeea8-00ca-4579-afe2-ad045da7696c',1,'2019-10-27',10,NULL,0),
(14,'fcf0e715-efa7-4967-adf5-03c97ac214e4',1,'2019-10-28',10,NULL,0),
(15,'7570b8dd-d644-4e51-93a3-8124b9efdeee',1,'2019-10-28',10,NULL,0),
(16,'76ab6e81-6633-4c80-a755-e46d60443347',1,'2019-10-28',10,NULL,0),
(17,'680477ba-4025-4522-a8a6-418b46fdaad4',1,'2019-10-28',10,NULL,0),
(18,'1f017ac7-c39e-4557-81cf-7a30d836a99b',1,'2019-10-28',10,NULL,0),
(19,'f9c61e27-4323-4ef7-9ce8-c0f1059ed040',1,'2019-10-28',10,NULL,0),
(20,'b54a6e3c-7e44-490c-a3f9-4476caea6706',1,'2019-10-28',10,NULL,0),
(21,'8d427c60-b00b-49fe-a4a9-377ec970c6f4',1,'2019-10-28',10,NULL,0),
(22,'25f58cae-838c-40cc-bc8a-89a0448af4d4',1,'2019-10-28',10,NULL,0),
(23,'d48985d6-d15a-4cde-9ace-0f6278381121',1,'2019-10-28',10,NULL,0),
(24,'3a42961d-7569-4129-806f-11719d2ca2d2',1,'2019-10-28',10,NULL,0),
(25,'93f7bd50-1824-40f6-aeee-49fa0c13cd4e',1,'2019-10-31',10,NULL,0),
(26,'02d110e7-982a-4158-9c8c-8a23251d8710',1,'2019-10-31',10,NULL,0),
(27,'ac0ba693-1ad5-4501-9a59-a0386d26cf32',1,'2019-10-31',10,NULL,0),
(28,'c149689c-339d-4fee-8dcb-94597e56d582',1,'2019-10-31',10,NULL,0),
(29,'152a9a26-07d2-4a8a-9f83-c5d75cb460ac',1,'2019-11-01',10,NULL,0),
(30,'cb9b5857-0f2e-42ff-b171-dfd96e7e7b3d',1,'2019-11-01',10,NULL,0),
(31,'63c601ab-e405-410a-b3b6-72c7fcc1f36d',2,'2019-11-01',10,NULL,0),
(32,'61431947-8159-4c16-b07e-3784efdfa95b',2,'2019-11-01',10,NULL,0),
(33,'63665c86-6a71-466b-ad3e-ad2f8083202b',2,'2019-11-02',10,NULL,0),
(34,'628843d1-9afb-476f-b48a-fe3fd3157e25',2,'2019-11-02',10,NULL,0),
(35,'62aae6a7-5c17-40e3-9e5c-ca6a654ee65f',2,'2019-11-02',10,NULL,0),
(36,'4511ccf7-bc93-4c2e-8bd5-680fbc373264',2,'2019-11-02',10,NULL,0),
(37,'908aa078-fe24-42f0-8e78-4c30a086b841',2,'2019-11-02',10,NULL,0),
(38,'4cc92f44-478c-4834-b1c4-38507ea8b0bb',2,'2019-11-04',10,NULL,0),
(39,'0d55c2ef-394b-4d32-a8bb-544fdad83a84',2,'2019-11-04',10,NULL,0),
(40,'30040370-cb23-460d-9a8b-08d91feaa4b6',2,'2019-11-04',10,NULL,0),
(41,'70d1836c-3589-4786-959d-c758efd96901',1,'2019-11-04',10,NULL,0),
(42,'f75b050e-f8ae-4233-bbf2-1e430c673a91',1,'2019-11-05',10,NULL,0),
(43,'435877ec-8cb5-4ee8-91ea-18e2ffc3e678',1,'2019-11-13',10,NULL,0),
(44,'320572b4-a351-4e02-b4b2-487d5707c565',1,'2019-11-13',10,NULL,0),
(45,'22356910-5b4d-4b79-98e9-99c57cee089d',1,'2019-11-13',10,NULL,0),
(46,'fc141ec8-c1bd-4397-8221-2d337df60cbb',1,'2019-11-13',10,NULL,0),
(47,'fcf8319b-df91-4535-86cb-407a4246e7c4',1,'2019-11-13',10,NULL,0),
(48,'99717df2-2381-49e5-96a8-2a22a3cd90ae',1,'2019-12-09',10,NULL,0),
(49,'e0b3069e-7471-4892-8924-c8dfca853684',1,'2019-12-21',10,NULL,0),
(50,'2a3baeb6-276a-4fb7-913f-b223cce7d808',1,'2019-12-21',10,NULL,0),
(51,'a093eb4f-6402-4a9b-832b-7e465035799b',1,'2019-12-21',10,NULL,0),
(52,'e71776a4-2600-45db-bc2c-9b1e856b2378',1,'2019-12-23',10,NULL,0),
(53,'68efdce5-3716-4588-a5ad-5bbd42a1bb56',1,'2019-12-23',10,NULL,0),
(54,'8dbcbc2f-5328-444d-8f9b-a8d11c7d2ae9',1,'2019-12-23',10,NULL,0),
(55,'ae81ab6d-ca6f-4583-87a1-b751eb9875a5',1,'2019-12-23',10,NULL,0),
(56,'520b2909-be1e-4b5c-bbfb-ffc249525467',1,'2019-12-23',10,NULL,0),
(57,'0c4cfe8f-cd55-42a6-a173-5f9d3b7d4fe7',1,'2019-12-27',10,NULL,0),
(58,'ba27599b-355c-458b-b087-cb2c00a802ca',1,'2019-12-27',10,NULL,0),
(59,'c3cb586c-8e44-4c0f-99ee-455c77f17ff2',1,'2019-12-28',10,NULL,0),
(60,'5bd75c5f-aac5-451f-ade5-2087bb26be02',1,'2020-01-06',10,NULL,0),
(61,'5a1cd11e-ad73-4783-b224-f5316fa48153',1,'2020-01-06',10,NULL,0),
(62,'37166821-ab87-4617-987c-4431b3d074b4',1,'2020-01-07',10,NULL,0),
(63,'9da50d9d-cd16-4cfe-ade1-cb29964fb1a1',1,'2020-01-07',10,NULL,0),
(64,'f5c92b9e-0ae1-4331-9f8f-f40dfedffe40',1,'2020-01-13',10,NULL,0),
(65,'6afc8115-f818-45b5-bf86-9df578a8e3d0',1,'2020-01-23',10,NULL,0),
(66,'d892b495-5594-4f51-a85a-7870e5b5ba15',1,'2020-01-23',10,NULL,0),
(67,'6c279aa7-0f69-4a07-b5f2-41c9cc97bb2c',1,'2020-01-23',10,NULL,0),
(68,'e7da328f-0ce9-4b7c-baee-e76e5eac8d3b',1,'2020-01-24',10,NULL,0),
(69,'42d98d7c-cfdc-4645-987d-eae6789b8ec1',1,'2020-01-25',10,NULL,0),
(70,'a4b72e59-37de-4fd8-93c8-b86830a1f74a',1,'2020-01-25',10,NULL,0),
(71,'22b7e224-6033-4d32-afd0-ceb1c8e0ec37',1,'2020-01-25',10,NULL,0),
(72,'4921c3f1-8fde-4018-8f03-246329a0c184',1,'2020-01-25',10,NULL,0),
(73,'e92399a5-2cff-4614-a8db-0e659c46ae5b',1,'2020-01-25',10,NULL,0),
(74,'4f274f08-7dd4-483c-b28b-6b2cbbe22d1b',1,'2020-01-25',10,NULL,0),
(75,'ed79c53b-7b7f-4cac-aca2-3a253bdc2be6',1,'2020-01-25',10,NULL,0),
(76,'d49d352a-61b3-49bd-bc08-8f909bf2b81d',1,'2020-02-01',10,NULL,0),
(123,'4a9e3c46-7004-49d5-9260-7689db517c50',1,'2020-02-14',10,NULL,0),
(124,'dfadff89-af46-4fcd-ae5f-0529e3c4bac4',1,'2020-02-14',10,NULL,0),
(125,'50f28660-9c85-40b3-8497-a733d255ae8a',1,'2020-03-03',10,NULL,0),
(126,'02ff2628-4ea4-4f23-8aa3-69165d8a83df',1,'2020-03-03',10,NULL,0),
(127,'269201c0-6ff6-46b8-8624-3c832d22be58',1,'2020-04-02',10,NULL,0);

/*Table structure for table `message` */

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `MESSAGEID` int(10) NOT NULL AUTO_INCREMENT,
  `USER_FROM` int(10) NOT NULL,
  `USER_TO` int(10) NOT NULL,
  `BODYCONTENT` varchar(500) COLLATE utf8_bin NOT NULL,
  `CREATEDATE` date DEFAULT NULL,
  PRIMARY KEY (`MESSAGEID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `message` */

insert  into `message`(`MESSAGEID`,`USER_FROM`,`USER_TO`,`BODYCONTENT`,`CREATEDATE`) values 
(1,5,13,'This is very first begining of message','2019-09-29'),
(2,13,5,'okay good plz put your question','2019-09-29'),
(3,9,16,'hallo 16 how are u',NULL),
(4,16,9,'i am good 9',NULL),
(5,5,13,'today is sunday','2019-09-29'),
(6,5,1,'Your ballence is very low you can\'t ask any questiuon','2019-11-01');

/*Table structure for table `notification` */

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `NOTIFICATION_ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `ARTICLE_ID` int(11) DEFAULT NULL,
  `SUMMERY_DETAILS` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `CATEGORY` int(11) DEFAULT NULL,
  `SUB_CATAGORY` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `DISPLAY_NAME` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `STATUS` int(2) NOT NULL DEFAULT '0',
  `CREATED_ON` date DEFAULT NULL,
  `TIMELINE_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`NOTIFICATION_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `notification` */

insert  into `notification`(`NOTIFICATION_ID`,`USER_ID`,`ARTICLE_ID`,`SUMMERY_DETAILS`,`CATEGORY`,`SUB_CATAGORY`,`DISPLAY_NAME`,`STATUS`,`CREATED_ON`,`TIMELINE_ID`) values 
(1,2,4,'this is test notification',12,'4','Test notification',50,NULL,0),
(2,2,5,'notification test',12,'4','notificaiton tst',50,NULL,0),
(13,48,0,'RT @turkialhussini1: .. \n\n?? ??? ?? ????? ?????? ???? ?? ???? ????? ????? ! \n \n???? ??? ???????? ???? ????? ??? ??????? ? \n\n.',0,NULL,'RT @turkialhussini1: .. \n\n?? ??? ?? ????? ?????? ?',49,NULL,0),
(14,48,0,'RT @dr_ibrahimarifi: @turkialhussini1 صدقت مهندس تركي\n\nوايضاً نحن ننصح دائماً مرضى حساسية الأنف والجيوب الأنفية بالسماح لنور الشمس بالدخول…',0,NULL,'RT @dr_ibrahimarifi: @turkialhussini1 صدقت مهندس ت',49,NULL,0),
(15,3,0,'Hola chicos, mi nombre es Avinash, un profesional de la informática que está explorando aplicaciones empresariales con dominio experto en la industria de fabricación, ventas, banca, finanzas y servicios de medios.',0,NULL,'Hola chicos, mi nombre es Avinash, un profesional d',49,NULL,0),
(16,1,0,'user , jay26 Nov 2019\nHow to do bidirection mapping in jpa , relation of one to one mapping from one entity to another entity. How much it is different from hibernate.',0,NULL,'user , jay26 Nov 2019\nHow to do bidirection mappin',49,NULL,0),
(17,1,0,'كيفية كتابة وحدة تحكم الراحة في التمهيد الربيع للحصول على تعيين الطلب. هل يمكننا إضافة مورد في طلب المعلمة',0,NULL,'كيفية كتابة وحدة تحكم الراحة في التمهيد الربيع للح',49,NULL,0),
(18,48,0,'RT @saudi_umran: تبارك جمعية #العمران للدكتور عبدالعزيز بن جار الله الدغيشم @aldegheishem رئيس مجلس إدارة شعبة أنظمة المعلومات الجغرافية GI…',0,NULL,'RT @saudi_umran: تبارك جمعية #العمران للدكتور عبدا',49,NULL,0),
(19,5,0,'اختبار \nTest',0,NULL,'اختبار \nTest',49,NULL,0),
(20,48,0,'RT @Kahrabaiat: صورة لتكريمي قبل ايام في #مؤتمر_الشبكات_الذكية من معالي الدكتور خالد السلطان رئيس مدينة الملك عبدالله للطاقة الذرية والمتجد…',0,NULL,'RT @Kahrabaiat: صورة لتكريمي قبل ايام في #مؤتمر_ال',49,NULL,0),
(21,48,0,'RT @Fahad_Allahaim: تكرار الوحدة يعطي انعكاس انيق جدا .. https://t.co/SkTgtckkMi',0,NULL,'RT @Fahad_Allahaim: تكرار الوحدة يعطي انعكاس انيق ',49,NULL,0),
(22,48,0,'RT @Umran_ID: يسر شعبة التصميم الداخلي بالجمعية السعودية لعلوم العمران فتح الأبواب لعضوية الشعبة وترحب بكل المهتمين في المجال للانضمام من خ…',0,NULL,'RT @Umran_ID: يسر شعبة التصميم الداخلي بالجمعية ال',49,NULL,0),
(23,5,0,'RT @AlhadabiBadar: تقول المهندسة المعمارية الامريكية جوليا مورغان-العمارة هي فن بصري والمباني تتحدث عن نفسها. تصميمنا الجديد بولاية السويق…',0,NULL,'RT @AlhadabiBadar: تقول المهندسة المعمارية الامريك',49,NULL,0),
(24,5,0,'RT @AlHulafa: طريقة تركيب شبك اللياسة الفايبر غلاس\n\n• اقوى من الشبك المعدني\n• سهل وسريع التركيب\n• اخطاء اقل في عمليه التركيب\n• يستخدم بين ا…',0,NULL,'RT @AlHulafa: طريقة تركيب شبك اللياسة الفايبر غلاس',49,NULL,0),
(25,1,0,'اسمي أفيناش كومار. أنا أعيش في بنغالورو',0,NULL,'اسمي أفيناش كومار. أنا أعيش في بنغالورو',49,'2020-01-04',0),
(30,48,0,'RT @turkialhussini1: @nada___97 الله يبعد عنك الاكتئاب .. بِسْمِ اللهِ أَرْقِيكَ، مِنْ كُلِّ شَيْءٍ يُؤْذِيكَ،',0,NULL,'RT @turkialhussini1: @nada___97 الله يبعد عنك الاك',49,'2020-01-06',0),
(31,48,0,'RT @nada___97: @turkialhussini1 مدري ليش هذي التصاميم على روعتها ودقتها الا انها تجيب لي اكتئاب ?',0,NULL,'RT @nada___97: @turkialhussini1 مدري ليش هذي التصا',49,'2020-01-06',0),
(32,48,0,'سور منزلي نفذت فيه كتلة عرض 40 سم وارتفاع 4 متر وطول 3.4 م وتم تكسيتها من رخام الكلكتا الاسود  .. الدرج والسور بورسلان اسباني نوع واحد بعد قصه مقاسات متعدده الباب ابسط مايكون تويبات حديد 4 سم في 4 سم عرض 1.4 م ونفس ارتفاع السور .. الاضاءه فقط حبتين على السور وحبه على الرخام https://t.co/vwiKnMCzxS',0,NULL,'سور منزلي نفذت فيه كتلة عرض 40 سم وارتفاع 4 متر وط',49,'2020-01-06',0),
(33,48,0,'RT @Fahad_Allahaim: نسال الله التوفيق والسداد في هذه الشعبة وان نقدم انا وزملائي ما هو مفيد لخدمة الوطن فيما يخص بتقنيات البناء https://t.c…',0,NULL,'RT @Fahad_Allahaim: نسال الله التوفيق والسداد في ه',49,'2020-01-06',0),
(34,51,0,'How to do bidirection mapping in jpa , relation of one to one mapping from one entity to another entity. How much it is different from hibernate.',0,NULL,'How to do bidirection mapping in jpa , relation of',49,'2020-01-06',0),
(35,51,0,'\nسور منزلي نفذت فيه كتلة عرض 40 سم وارتفاع 4 متر وطول 3.4 م وتم تكسيتها من رخام الكلكتا الاسود .. الدرج والسور بورسلان اسباني نوع واحد بعد قصه مقاسات متعدده الباب ابسط مايكون تويبات حديد 4 سم في 4 سم عرض 1.4 م ونفس ارتفاع السور .. الاضاءه فقط حبتين على السور وحبه على الرخام',0,NULL,'\nسور منزلي نفذت فيه كتلة عرض 40 سم وارتفاع 4 متر و',49,'2020-01-07',0),
(40,26,0,'asd',0,NULL,'asd',49,'2020-01-20',0),
(41,1,0,'',0,NULL,'',49,'2020-01-24',0),
(42,1,0,'هنا هو الجدول الزمني للاختبار وأنها تعمل بشكل جيد.',0,NULL,'هنا هو الجدول الزمني للاختبار وأنها تعمل بشكل جيد.',49,'2020-01-24',0),
(43,1,0,'في العادة، يقوم المرشحين بالقاء خطبة قصيرة قبل التصويت',0,NULL,'في العادة، يقوم المرشحين بالقاء خطبة قصيرة قبل الت',49,'2020-01-24',0),
(44,1,0,'بالقاء خطبة قصيرة قبل التصويت بما أن بورت سوف يثبت لكم أن الخطب مملة',0,NULL,'بالقاء خطبة قصيرة قبل التصويت بما أن بورت سوف يثبت',49,'2020-01-24',0),
(45,1,0,'Delhi assembly election is on 8th Feb. Keep count for your valuable votes.',0,NULL,'Delhi assembly election is on 8th Feb. Keep count ',49,'2020-01-25',0),
(46,1,0,'Test',0,NULL,'Test',49,'2020-01-25',0),
(47,1,0,'اببااتتوو الللاننعفبىاتنننن',0,NULL,'اببااتتوو الللاننعفبىاتنننن',49,'2020-01-25',0),
(48,1,0,'content://media/external/images/media/46134',0,NULL,'content://media/external/images/media/46134',49,'2020-01-28',0),
(49,1,0,'/storage/emulated/0/DCIM/Camera/Like_6785736832278221935.mp4',0,NULL,'/storage/emulated/0/DCIM/Camera/Like_6785736832278',49,'2020-01-28',0),
(50,1,0,'content://com.google.android.apps.photos.contentprovider/-1/2/content%3A%2F%2Fmedia%2Fexternal%2Fvideo%2Fmedia%2F46224/ORIGINAL/NONE/video%2Fmp4/616830718',0,NULL,'content://com.google.android.apps.photos.contentpr',49,'2020-01-28',0),
(51,1,0,'content://media/external/images/media/46138',0,NULL,'content://media/external/images/media/46138',49,'2020-01-28',0),
(52,1,0,'Failure will never overtake me if my determination to succeed is strong enough',0,NULL,'Failure will never overtake me if my determination',49,'2020-01-28',0),
(53,26,0,'26_56_9861db7e-8b1f-4e7a-bbce-0e453041e74a-trailer_hd.mp4',0,NULL,'26_56_9861db7e-8b1f-4e7a-bbce-0e453041e74a-trailer',49,'2020-01-29',0),
(54,1,0,'Knowing is not enough, we must apply. Willing is not enough, we must do.',0,NULL,'Knowing is not enough, we must apply. Willing is n',49,'2020-01-29',0),
(55,1,0,'Knowing is not enough, we must apply',0,NULL,'Knowing is not enough, we must apply',49,'2020-01-29',0),
(56,26,0,'26_56_065fb788-9868-425a-8c58-9b8bbd73c869-y2mate.com - akshayakalpa_organic_milk_6SWVV7LELSk_240p.mp4',0,NULL,'26_56_065fb788-9868-425a-8c58-9b8bbd73c869-y2mate.',49,'2020-01-30',0),
(57,1,0,'1_56_52012bff-8dc5-42fd-9cd3-b5294acc1a6b-WhatsApp Video 2020-01-30 at 1.03.58 PM.mp4',0,NULL,'1_56_52012bff-8dc5-42fd-9cd3-b5294acc1a6b-WhatsApp',49,'2020-01-31',0),
(58,1,0,'1_58_7fa74d87-98d4-4110-9e16-de0faae74051-peripherals.jpg',0,NULL,'1_58_7fa74d87-98d4-4110-9e16-de0faae74051-peripher',49,'2020-01-31',0),
(59,1,0,'1_58_e3d8f975-2feb-48f1-8f40-121b29d03ce5-images.jpg',0,NULL,'1_58_e3d8f975-2feb-48f1-8f40-121b29d03ce5-images.j',49,'2020-01-31',0),
(60,1,0,'1_58_aa3e2193-64d1-4f67-aee1-4591c78b18fc-images.jpg',0,NULL,'1_58_aa3e2193-64d1-4f67-aee1-4591c78b18fc-images.j',49,'2020-01-31',0),
(61,1,0,'1_58_dff5af3e-325a-46cb-9406-31bb443f607d-5cc230d9c3a7c15db8365bd5-1136-853.jpg',0,NULL,'1_58_dff5af3e-325a-46cb-9406-31bb443f607d-5cc230d9',49,'2020-01-31',0),
(62,1,0,'1_58_5402b020-2cea-4ed5-9cca-4ff197720cca-b844a205b331be4dd32fd0472af96261.jpg',0,NULL,'1_58_5402b020-2cea-4ed5-9cca-4ff197720cca-b844a205',49,'2020-01-31',0),
(63,1,0,'1_56_e53c4260-ebe2-4ded-9811-2b07ed3732d5-Like_6785736832278221935.mp4',0,NULL,'1_56_e53c4260-ebe2-4ded-9811-2b07ed3732d5-Like_678',49,'2020-01-31',0),
(64,1,0,'',0,NULL,'',49,'2020-01-31',0),
(65,1,0,'',0,NULL,'',49,'2020-01-31',0),
(66,1,0,'',0,NULL,'',49,'2020-01-31',0),
(67,1,0,'1_55_ac889052-dbdc-4581-865d-add0d70b2b85-Tujhe Kitna Chahein Aur Hum | Kabir Singh | Jubin Nautiyal Live | Mithoon | Thomso 2019 | IIT Roorke',0,NULL,'1_55_ac889052-dbdc-4581-865d-add0d70b2b85-Tujhe Ki',49,'2020-01-31',0),
(68,1,0,'1_56_c88651f5-acd3-4cfb-94be-0ec0dd38d302-video.mp4',0,NULL,'1_56_c88651f5-acd3-4cfb-94be-0ec0dd38d302-video.mp',49,'2020-01-31',0),
(69,1,0,'1_56_05e50f1b-6624-41a1-ba01-ffe197c5d8b8-video.mp4',0,NULL,'1_56_05e50f1b-6624-41a1-ba01-ffe197c5d8b8-video.mp',49,'2020-01-31',0),
(70,1,0,'1_56_baf6313a-2f5e-43c7-8c77-f18e87e18d00-timeline.mp4',0,NULL,'1_56_baf6313a-2f5e-43c7-8c77-f18e87e18d00-timeline',49,'2020-01-31',0),
(71,1,0,'1_56_4316e317-821c-420d-b66e-e70863def247-thoughtPF_timeline.mp4',0,NULL,'1_56_4316e317-821c-420d-b66e-e70863def247-thoughtP',49,'2020-01-31',0),
(72,1,0,'1_58_388b2ed6-f5b3-4fa4-af1f-5af957053691-image-058c5db4-828d-4262-a87a-2ed69a31df2e.jpg',0,NULL,'1_58_388b2ed6-f5b3-4fa4-af1f-5af957053691-image-05',49,'2020-01-31',0),
(73,1,0,'1_58_8d7b057e-734f-4bc0-9a73-cbf969302663-thoughtPF_image.jpg',0,NULL,'1_58_8d7b057e-734f-4bc0-9a73-cbf969302663-thoughtP',49,'2020-01-31',0),
(74,1,0,'1_58_dcfb17e2-80e6-419c-aaaf-a15573051549-thoughtPF_image.jpg',0,NULL,'1_58_dcfb17e2-80e6-419c-aaaf-a15573051549-thoughtP',49,'2020-01-31',0),
(75,1,0,'1_58_6d160cae-6bc0-4abd-9614-fd14042bda4c-image-319b6693-b297-4b12-9919-f5ab434446d6.jpgthoughtPF_image.jpg',0,NULL,'1_58_6d160cae-6bc0-4abd-9614-fd14042bda4c-image-31',49,'2020-01-31',0),
(76,1,0,'1_58_f50f3f1a-dbd5-4142-a5db-c2f8c62ba393-thoughtPF_imageimage-a16576d7-bc7b-4ac1-94d8-eb09914c3b8d.jpg',0,NULL,'1_58_f50f3f1a-dbd5-4142-a5db-c2f8c62ba393-thoughtP',49,'2020-01-31',0),
(77,1,0,'1_58_82885be4-7c0b-44bc-b304-275938ea9dc7-thoughtPF_imageb844a205b331be4dd32fd0472af96261.jpg',0,NULL,'1_58_82885be4-7c0b-44bc-b304-275938ea9dc7-thoughtP',49,'2020-01-31',0),
(78,1,0,'1_55_e0b49b98-4c17-4360-b38c-2e7e7b9f5761-thoughtPF_audioTujhe Kitna Chahein Aur Hum | Kabir Singh | Jubin Nautiyal Live | Mithoon | Thomso 2019 | IIT Roorke',0,NULL,'1_55_e0b49b98-4c17-4360-b38c-2e7e7b9f5761-thoughtP',49,'2020-01-31',0),
(79,1,0,'Abcd check',0,NULL,'Abcd check',49,'2020-01-31',0),
(80,1,0,'1_58_fd3265c9-3cb1-4068-abd3-a6c24668dbc7-thoughtPF_imageimage-40cfc759-4ae8-41f6-9b94-ecba056123f3.jpg',0,NULL,'1_58_fd3265c9-3cb1-4068-abd3-a6c24668dbc7-thoughtP',49,'2020-01-31',0),
(81,1,0,'1_55_e0f02e08-8f95-4164-b6f0-e92bd4fc0960-thoughtPF_audioTujhe Kitna Chahein Aur Hum | Kabir Singh | Jubin Nautiyal Live | Mithoon | Thomso 2019 | IIT Roorke',0,NULL,'1_55_e0f02e08-8f95-4164-b6f0-e92bd4fc0960-thoughtP',49,'2020-01-31',0),
(82,1,0,'1_56_ed53bbd4-b2be-44da-93c9-5fb375b4ac64-thoughtPF_timeline.mp4',0,NULL,'1_56_ed53bbd4-b2be-44da-93c9-5fb375b4ac64-thoughtP',49,'2020-01-31',0),
(83,1,0,'1_56_0a23a3ae-c57c-40aa-a81f-9d71dc8a5565-thoughtPF_timeline.mp4',0,NULL,'1_56_0a23a3ae-c57c-40aa-a81f-9d71dc8a5565-thoughtP',49,'2020-01-31',0),
(84,1,0,'1_58_180d1861-b0e4-46be-8132-f82dc5af665d-thoughtPF_imageimage-e64e21fb-a7f1-4e9c-8056-d94fd7228165.jpg',0,NULL,'1_58_180d1861-b0e4-46be-8132-f82dc5af665d-thoughtP',49,'2020-01-31',0),
(85,1,0,'Test ask question',0,NULL,'Test ask question',49,'2020-02-03',0),
(86,1,0,'1_56_5d6629f8-b8f1-403f-9898-39c7053b0526-thoughtPF_timeline.mp4',0,NULL,'1_56_5d6629f8-b8f1-403f-9898-39c7053b0526-thoughtP',49,'2020-02-03',0),
(87,1,0,'1_56_9c060a34-e0e3-4add-8522-7367e0929e81-thoughtPF_timeline.mp4',0,NULL,'1_56_9c060a34-e0e3-4add-8522-7367e0929e81-thoughtP',49,'2020-02-03',0),
(88,2,0,'',0,NULL,'',49,'2020-02-03',0),
(89,51,0,'',0,NULL,'',49,'2020-02-03',0),
(90,48,0,'What\'s your name? ',0,NULL,'What\'s your name? ',49,'2020-02-03',0),
(91,2,0,'What do you have? ',0,NULL,'What do you have? ',49,'2020-02-03',0),
(92,51,0,'Ghtdhfijgfjy',0,NULL,'Ghtdhfijgfjy',49,'2020-02-04',0),
(93,51,0,'Asdf',0,NULL,'Asdf',49,'2020-02-08',0),
(94,1,0,'1_56_12bd614f-3509-4365-bfd3-feac44ce796c-thoughtPF_timeline.mp4',0,NULL,'1_56_12bd614f-3509-4365-bfd3-feac44ce796c-thoughtP',49,'2020-02-09',0),
(95,1,0,'1_56_df96b6d7-f63d-4abd-bc32-f49e4431b4a7-thoughtPF_timeline.mp4',0,NULL,'1_56_df96b6d7-f63d-4abd-bc32-f49e4431b4a7-thoughtP',49,'2020-02-09',0),
(96,2,0,'Test ask question',0,NULL,'Test ask question',49,'2020-02-10',58),
(97,2,0,'Test ask question',0,NULL,'Test ask question',49,'2020-02-10',59),
(98,1,0,'Test ask question',0,NULL,'Test ask question',49,'2020-02-10',59),
(99,2,0,'Test ask question second time',0,NULL,'Test ask question second time',49,'2020-02-10',59),
(100,2,0,'Ughyyy',0,NULL,'Ughyyy',49,'2020-02-10',54),
(101,48,0,'Ask',0,NULL,'Ask',49,'2020-02-11',59),
(102,48,0,'Question for free',0,NULL,'Question for free',49,'2020-02-11',59),
(103,2,0,'I\'m asking free question to jay user ',0,NULL,'I\'m asking free question to jay user ',49,'2020-02-11',54),
(104,2,0,'Test ask question second time',0,NULL,'Test ask question second time',49,'2020-02-11',59),
(105,2,0,'Ask questions ',0,NULL,'Ask questions ',49,'2020-02-11',59),
(106,2,0,'Ask questions 124',0,NULL,'Ask questions 124',49,'2020-02-11',59),
(107,2,0,'Ask 12345',13,NULL,'Ask 12345',49,'2020-02-11',141),
(108,1,0,'Great color mixing activities for kids, including how to mix paint, color science ... FREE printable book activity for toddlers to go along with',12,NULL,'Great color mixing activities for kids, including ',49,'2020-02-11',142),
(109,51,0,'This guide walks you through the process of building an application that uses Spring Data JPA to store and retrieve data in a relational database.',13,NULL,'This guide walks you through the process of buildi',49,'2020-02-11',143),
(110,26,0,'Asking question here',13,NULL,'Asking question here',49,'2020-02-12',144),
(111,2,0,'Asking free question\n',13,NULL,'Asking free question\n',49,'2020-02-12',145),
(112,47,0,'Test ask question second time',16,NULL,'Test give Answer',49,'2020-02-14',133),
(113,1,0,'Hi jaynt',16,NULL,'Hi jaynt',49,'2020-02-14',146),
(114,51,0,'Hi jaynt',16,NULL,'Hi Avinash',49,'2020-02-15',146),
(115,48,0,'RT @Eng_A_C: الان افضل وقت لصيانة المكيفات لأهميتها في:\nتقليل الاعطال في فترة الصيف\nوتقليل استهلاك الكهرب\nوالاستفادة من كفاءة المكيف بالكام…',14,NULL,'RT @Eng_A_C: الان افضل وقت لصيانة المكيفات لأهميته',49,'2020-02-22',147),
(116,48,0,'ا',14,NULL,'ا',49,'2020-02-22',148),
(117,26,0,'االب',13,NULL,'االب',49,'2020-02-22',149),
(118,1,0,'مجرد تجربه للتايم لاين .....\n\nفيه حاجات لازم تتضبط مثل ارسال السوال بوب اوت كتابه فقط ولها حد اعلى ?',12,NULL,'مجرد تجربه للتايم لاين .....\n\nفيه حاجات لازم تتضبط',49,'2020-02-25',150),
(119,1,0,'',12,NULL,'',49,'2020-03-07',151),
(120,1,0,'',12,NULL,'',49,'2020-03-07',152),
(121,1,0,'',12,NULL,'',49,'2020-03-07',153),
(122,51,0,'51_58_c816f555-b982-4833-9590-be730d788139-thoughtPF_imageimage-8a6f9c33-3825-4a73-81a8-432d56befb97.jpg',13,NULL,'51_58_c816f555-b982-4833-9590-be730d788139-thought',49,'2020-03-07',154);

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `POST_SUBCATAGORY` int(11) DEFAULT NULL,
  `POST_ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `POST_CATEGORY` int(11) NOT NULL,
  `ARTICLE` int(11) NOT NULL,
  `ACTIVE` tinyint(1) DEFAULT NULL,
  `BUDGET` int(11) DEFAULT NULL,
  `CURRENCY` int(11) NOT NULL,
  PRIMARY KEY (`POST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `post` */

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `CATEGORY` int(50) DEFAULT NULL,
  `BRAND` int(30) DEFAULT NULL,
  `SHOP_ID` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `AVATAR` varchar(60) COLLATE utf8_bin DEFAULT NULL,
  `PRICE` float DEFAULT NULL,
  `QUANTITY` int(10) DEFAULT NULL,
  `REVIEW` varchar(156) COLLATE utf8_bin DEFAULT NULL,
  `DISCREPTION` varchar(510) COLLATE utf8_bin DEFAULT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  `BARCOADE` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `STOCK` int(4) DEFAULT NULL,
  `SALE_PRICE` float DEFAULT NULL,
  `COST_PRICE` float DEFAULT NULL,
  `OLD_PRICE` float DEFAULT NULL,
  `OFFER_PERCENT` int(5) DEFAULT NULL,
  `OFFER_FROM` date DEFAULT NULL,
  `OFFER_LAST` date DEFAULT NULL,
  `OFFER_ACTIVE_END` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `product` */

insert  into `product`(`ID`,`NAME`,`CATEGORY`,`BRAND`,`SHOP_ID`,`AVATAR`,`PRICE`,`QUANTITY`,`REVIEW`,`DISCREPTION`,`IS_ACTIVE`,`IS_DELETED`,`BARCOADE`,`STOCK`,`SALE_PRICE`,`COST_PRICE`,`OLD_PRICE`,`OFFER_PERCENT`,`OFFER_FROM`,`OFFER_LAST`,`OFFER_ACTIVE_END`) values 
(1,'sweet',10,10,'Avi23','dfgdfg',420,5,'good','good Quality',0,0,'111111',1,400,300,200,4,'2021-04-10','2021-04-11',1),
(2,'Soap',21,21,'Avi23','ewwe',3223,3232,'qweqw','wedfwe',0,0,'sdfs',2,300,200,100,2,'2021-04-08','2021-04-20',0),
(3,'pen',0,21,'Avi23',NULL,0,0,NULL,NULL,0,0,NULL,3,500,200,500,5,'2021-04-10','2021-04-19',1),
(4,'Mango',10,10,'Shivam232',NULL,420,5,'good','good Quality',1,0,'111111',1,400,300,200,4,'2021-04-14','2021-04-20',1),
(5,'rice',12,2133,'rice54444',NULL,420,44,'Best quality','This is my product',1,0,'0',5,300,300,100,3,'2021-04-16','2021-04-19',0),
(6,'Mango',10,10,'Shivam232',NULL,420,5,'good','good Quality',0,0,'111111',1,400,300,200,4,'2021-04-14','2021-04-14',1),
(7,'sweet',10,10,'Avi232',NULL,420,5,'good','good Quality',0,0,'111111',1,400,300,200,4,'2021-04-14','2021-04-14',1);

/*Table structure for table `product_list` */

DROP TABLE IF EXISTS `product_list`;

CREATE TABLE `product_list` (
  `Id` int(2) NOT NULL AUTO_INCREMENT,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `USER_ID` int(50) DEFAULT NULL,
  `PRODUCT_NAME` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `CREATED_ON` date DEFAULT NULL,
  `PRODUCT_QUANTITY` float DEFAULT NULL,
  `PRICE` float DEFAULT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  `PRODUCT_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `OFFER` int(5) DEFAULT NULL,
  `CART_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `product_list` */

insert  into `product_list`(`Id`,`SHOP_ID`,`USER_ID`,`PRODUCT_NAME`,`CREATED_ON`,`PRODUCT_QUANTITY`,`PRICE`,`IS_ACTIVE`,`IS_DELETED`,`PRODUCT_ID`,`OFFER`,`CART_ID`) values 
(1,'Avi23',1,'computer','2021-04-09',4,40000,1,0,'com33',4,1),
(2,'pri33',2,'com','2021-04-09',4,6000,1,0,'mouse33',5,2),
(3,'avi22',3,'system','2021-04-10',33,50000,1,0,'mouse23',3,3),
(4,'shi33',4,'monuter','2021-04-10',55,10000,1,0,'home33',4,4),
(5,'shi22',4,'com','2021-04-17',33,10000,1,0,'house22',4,3),
(6,'pri66',3,'mobile','2021-04-11',44,40000,1,0,'com22',4,5);

/*Table structure for table `profile` */

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `PROFILE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `CATEGORY` int(11) NOT NULL,
  `ARTICLE_ID` int(11) NOT NULL,
  `BACKGROUND_EXPERTISE` varchar(500) DEFAULT NULL,
  `SUMMERY_DETAILS` varchar(500) DEFAULT NULL,
  `SUB_CATAGORY` varchar(50) DEFAULT NULL,
  `SERVED_CONSULTATION` int(10) DEFAULT NULL,
  `CONSULTATION_PRICE` int(10) DEFAULT NULL,
  `TOTAL_EARNINGS` int(10) DEFAULT NULL,
  `AVG_RATING` int(10) DEFAULT NULL,
  `AVAILIBILITY` int(10) DEFAULT NULL,
  `AVG_RESPONSE_TIME` int(10) DEFAULT NULL,
  `DISPLAY_NAME` varchar(50) DEFAULT NULL,
  `LANGUAGE_PRIMARY` int(2) NOT NULL DEFAULT '0',
  `LANGUAGE_SECONDARY` int(2) NOT NULL DEFAULT '0',
  `KEYWORD` varchar(200) NOT NULL DEFAULT 'NA',
  `TWITTER_HANDLE` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`PROFILE_ID`,`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `profile` */

insert  into `profile`(`PROFILE_ID`,`USER_ID`,`CATEGORY`,`ARTICLE_ID`,`BACKGROUND_EXPERTISE`,`SUMMERY_DETAILS`,`SUB_CATAGORY`,`SERVED_CONSULTATION`,`CONSULTATION_PRICE`,`TOTAL_EARNINGS`,`AVG_RATING`,`AVAILIBILITY`,`AVG_RESPONSE_TIME`,`DISPLAY_NAME`,`LANGUAGE_PRIMARY`,`LANGUAGE_SECONDARY`,`KEYWORD`,`TWITTER_HANDLE`) values 
(1,1,12,43,'IT cloud computing and infrastructure',' cloud , Google cloud. architect, cms',NULL,0,30,0,0,43,0,'Kumar Avinash',46,2,'','jaykrs'),
(2,3,13,2,'IT marketing analyst','I have been working on different IT service and product marketing startgies from last 10 year. worked on marketing analysis of various domain from treditional legacy system to modern architectuere. Passionate to learn new ideas on marketing stratgities.','2',0,6,0,0,43,0,'Jatin Consultant',46,47,'',''),
(3,7,12,43,'IT','Per the HTML specification, the default style for <summary> elements includes display: list-item. This makes it possible to change or remove the icon displayed as the disclosure widget next to the label from the default, which is typically a triangle.You can also change the style to display: block to remove the disclosure triangle.See the Browser compatibility section for details, as not all browsers support full functionality of this element yet.',NULL,0,5,0,0,43,0,'Omkar Consultant',46,47,'',NULL),
(4,5,13,123,'cloud , Google cloud. architect, Manager','cloud , Google cloud. architect, Manager','2',0,5,0,0,43,0,'Javed Ahmad Khan',46,47,'','Thoughtconstru1'),
(5,4,22,43,'today is sunday','today is sunday summery','21',0,10,0,0,43,0,'Vikash Kumar',46,48,'',NULL),
(9,26,13,43,'React-Native, Java, Oracle, Mysql','Fresher',NULL,0,10,0,0,53,0,NULL,0,0,'NA',NULL),
(10,48,14,43,'Businesses law','Businesses and law',NULL,0,5,0,0,53,0,NULL,0,0,'NA','Turkialhussini1'),
(11,2,13,43,'Ui/server','Bca/Mca',NULL,0,5,0,0,53,0,NULL,0,0,'NA',NULL),
(12,51,13,43,'React Native ','BCA',NULL,0,5,0,0,53,0,'Kumar  Avinash ',46,0,'NA',NULL),
(13,47,24,0,NULL,NULL,NULL,0,0,0,0,44,0,NULL,48,0,'NA',NULL),
(14,66,15,0,NULL,NULL,NULL,0,0,0,0,53,0,'Kumar Vijay',46,0,'NA',NULL);

/*Table structure for table `review` */

DROP TABLE IF EXISTS `review`;

CREATE TABLE `review` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PRODUCT_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `USER_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `COMMENT` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `NAME` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `review` */

insert  into `review`(`ID`,`PRODUCT_ID`,`USER_ID`,`SHOP_ID`,`COMMENT`,`NAME`,`IS_DELETED`,`IS_ACTIVE`) values 
(1,'pro123','radha123','Avi23','Best product','radah',0,1),
(2,'shop12','radha123hjh','Avi23','good product','radah',0,1),
(3,'computer123','user123','shop12','this is my','mohan',0,1),
(4,'mouse123','radha123','shop420','where is my product','radah',0,0),
(5,'shop124','radha123hjh','shop420','good product','radah',0,0);

/*Table structure for table `salary` */

DROP TABLE IF EXISTS `salary`;

CREATE TABLE `salary` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `EMPLOYEE_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `ADVANCE_SALARY` float DEFAULT NULL,
  `TOTAL_SALARY` float DEFAULT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `SALARY` float DEFAULT NULL,
  `DEDUCTION` float DEFAULT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `salary` */

insert  into `salary`(`ID`,`EMPLOYEE_ID`,`ADVANCE_SALARY`,`TOTAL_SALARY`,`SHOP_ID`,`SALARY`,`DEDUCTION`,`IS_DELETED`,`IS_ACTIVE`) values 
(1,'ram2321565',3433.44,34334,'Avi23',5000,3500,0,1),
(2,'ram234',54000,66000,'Avi23',3000,6000,0,0),
(3,'ram2321565',3433.44,34334,'Avi23',0,0,0,0),
(4,'mohan2321',0,0,'shop232',0,0,0,0),
(5,'Avinash2321',3433.44,34334,'shop232',5000,3500,0,0);

/*Table structure for table `timeline` */

DROP TABLE IF EXISTS `timeline`;

CREATE TABLE `timeline` (
  `TIMELINE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `CONSULTANT_ID` int(11) DEFAULT NULL,
  `Q_ARTICLE` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `A_ARTICLE` text COLLATE utf8_bin,
  `LIKE_COUNT` int(4) unsigned zerofill DEFAULT NULL,
  `DISLIKE_COUNT` int(4) unsigned zerofill DEFAULT NULL,
  `SHARE_URL` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `LIKE_USER_ID` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `DISLIKE_USER_ID` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `ANSWER_STATUS` tinyint(1) DEFAULT NULL,
  `Q_TYPE` int(2) unsigned zerofill DEFAULT NULL,
  `CREATED_ON` date NOT NULL,
  `ANSWERED_ON` date DEFAULT NULL,
  `CATAGORY_ID` int(2) NOT NULL DEFAULT '0',
  `TWITTER_ID` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`TIMELINE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `timeline` */

insert  into `timeline`(`TIMELINE_ID`,`USER_ID`,`CONSULTANT_ID`,`Q_ARTICLE`,`A_ARTICLE`,`LIKE_COUNT`,`DISLIKE_COUNT`,`SHARE_URL`,`LIKE_USER_ID`,`DISLIKE_USER_ID`,`ANSWER_STATUS`,`Q_TYPE`,`CREATED_ON`,`ANSWERED_ON`,`CATAGORY_ID`,`TWITTER_ID`) values 
(1,0,2,'How to do bidirection mapping in jpa , relation of one to one mapping from one entity to another entity. How much it is different from hibernate.',NULL,0000,0000,NULL,'50,2,47,51','26,51,47,57',0,54,'2019-11-26',NULL,12,NULL),
(3,2,2,'what is best possible way to reach Sofia in Bulgaria from London via train. My preferred way is either train or self drive car.',NULL,0000,0002,NULL,'50,51','47,1',0,54,'2019-11-26',NULL,12,NULL),
(4,2,2,'كيفية كتابة وحدة تحكم الراحة في التمهيد الربيع للحصول على تعيين الطلب. هل يمكننا إضافة مورد في طلب المعلمة',NULL,0000,0001,NULL,'50,51','1',0,54,'2019-11-26',NULL,12,NULL),
(5,2,2,'Vous pourriez ne pas être intéressé par ce guide, si vous avez initialisé l\'application à l\'aide du modèle UI Kitten car il comprend déjà Eva Icons. Quoi qu\'il en soit, si vous voulez savoir comment utiliser des packages d\'icônes tiers comme react-native-vector-icons, utilisez ce guide pour le faire fonctionner dans votre application.',NULL,0001,0001,NULL,'51,48,47','47',0,54,'2019-11-26',NULL,12,NULL),
(6,2,2,'Hola chicos, mi nombre es Avinash, un profesional de la informática que está explorando aplicaciones empresariales con dominio experto en la industria de fabricación, ventas, banca, finanzas y servicios de medios.',NULL,0000,0001,NULL,'','51',0,54,'2019-12-17',NULL,12,NULL),
(7,3,3,'The supreme court of the Netherlands has ordered the government to reduce greenhouse gas emissions sharply. https://t.co/BCHkd7LpQd https://t.co/BCHkd7LpQd',NULL,0002,0001,NULL,'48,1','26',0,54,'2019-12-21',NULL,13,'1208366086145617920'),
(8,0,3,'RT @nytclimate: The supreme court of the Netherlands has ordered the government to reduce greenhouse gas emissions sharply. https://t.co/Xu…',NULL,0001,0001,NULL,'50','1',0,54,'2019-12-21',NULL,13,'1208365939164532741'),
(9,0,3,'RT @latimes: U.S. Steel to cut 1,545 Michigan jobs as weakness overwhelms Trump\'s protection https://t.co/CiLyNoFXpx',NULL,0002,0000,NULL,'50,1','',0,54,'2019-12-21',NULL,13,'1208365893052334081'),
(10,0,3,'Gazprom and Ukraine reached an agreement that will allow Russian gas to flow to Europe via its neighbor through the end of 2024 and settle all of the related legal disputes https://t.co/eRsVmzgZyU https://t.co/eRsVmzgZyU',NULL,0002,0001,NULL,'50,1','1',0,54,'2019-12-21',NULL,13,'1208365501728079872'),
(11,0,3,'RT @business: Gazprom and Ukraine reached an agreement that will allow Russian gas to flow to Europe via its neighbor through the end of 20…',NULL,0000,0000,NULL,'',NULL,0,54,'2019-12-21',NULL,13,'1208365374984445952'),
(12,0,3,'RT @ShekharGupta: India’s new Muslim flaunts the Tricolour on the steps of Jama Masjid, sings national anthem & isn’t afraid to look Muslim…',NULL,0000,0000,NULL,'',NULL,0,54,'2019-12-21',NULL,13,'1208365096474333184'),
(13,0,3,'India’s new Muslim flaunts the Tricolour on the steps of Jama Masjid, sings national anthem & isn’t afraid to look Muslim...\n\nAnd wouldn’t allow any majority to reimagine the Constitution’s republic..\n\nhttps://t.co/2ESYN2D1gw https://t.co/2ESYN2D1gw',NULL,0000,0000,NULL,NULL,NULL,0,54,'2019-12-21',NULL,13,'1208365086634598400'),
(14,0,3,'RT @business: Amazon seeks out first Irish warehouse to fulfill orders currently shipped from the U.K. as Brexit deadline looms https://t.c…',NULL,0000,0000,NULL,NULL,NULL,0,54,'2019-12-21',NULL,13,'1208364653379649539'),
(15,0,3,'\"How can you detain passengers in a bus, can you please explain it to me?\" Govind, a student on the bus said. \"We are in a fascist state.” \n\n@ahanpenkar reports. https://t.co/RXKHUy4Bzt https://t.co/RXKHUy4Bzt',NULL,0000,0000,NULL,NULL,NULL,0,54,'2019-12-21',NULL,13,'1208364340040085504'),
(16,0,3,'CAA Protests: UP Police Detain, Threaten, Beat Up Activists, Journalist in Lucknow https://t.co/xt4vdb4Uru',NULL,0000,0000,NULL,NULL,NULL,0,54,'2019-12-21',NULL,13,'1208364055477604352'),
(17,0,3,'RT @thecaravanindia: \"How can you detain passengers in a bus, can you please explain it to me?\" Govind, a student on the bus said. \"We are…',NULL,0000,0000,NULL,NULL,NULL,0,54,'2019-12-21',NULL,13,'1208363796550447105'),
(18,0,3,'RT @the_hindu: At least 11 people, including an 8-year-old boy, have lost their lives in #UttarPradesh as the protests against the Citizens…',NULL,0000,0000,NULL,NULL,NULL,0,54,'2019-12-21',NULL,13,'1208363730074865665'),
(19,0,3,'RT @LiveLawIndia: Internet Shut Down Explainer By Apar Gupta[Video]\n@apar1984 \n@internetfreedom \n#internetshutdown \n\nhttps://t.co/pSrbm74gUi',NULL,0001,0000,NULL,'1',NULL,0,54,'2019-12-21',NULL,13,'1208363576638894080'),
(20,0,3,'Legality Of Internet Shut Downs Explained By Apar Gupta[Video]\n\nhttps://t.co/skxiJr7TBb https://t.co/skxiJr7TBb',NULL,0000,0000,NULL,NULL,NULL,0,54,'2019-12-21',NULL,13,'1208363206642733056'),
(21,0,3,'Goldman Sachs is negotiating with U.S. prosecutors to pay a fine of as much as $2 billion, and have a subsidiary plead guilty, to settle claims about its role in a Malaysian fund scandal, a person with knowledge of the matter said \nVia @newyorktimes',NULL,0001,0000,NULL,'1',NULL,0,54,'2019-12-21',NULL,13,'1208305011249336320'),
(22,0,3,'RT @nytimesbusiness: Goldman Sachs is negotiating with U.S. prosecutors to pay a fine of as much as $2 billion, and have a subsidiary plead…',NULL,0000,0000,NULL,NULL,NULL,0,54,'2019-12-21',NULL,13,'1208304632872595456'),
(23,0,3,'No more religious exemptions: Montreal is taxing churches https://t.co/ymNOa4GcCO',NULL,0000,0000,NULL,NULL,NULL,0,54,'2019-12-21',NULL,13,'1208285037134831616'),
(24,0,3,'Jared Kushner \'admitted Donald Trump lies to his base because he thinks they\'re stupid\' https://t.co/AGC2qvXU4p',NULL,0001,0000,NULL,'1',NULL,0,54,'2019-12-21',NULL,13,'1208284575157440517'),
(25,0,2,'How to do bidirection mapping in jpa , relation of one to one mapping from one entity to another entity. How much it is different from hibernate. Avinash',NULL,0001,0002,NULL,'48','47,1',0,54,'2019-12-26',NULL,14,NULL),
(26,0,3,'How to do bidirection mapping in jpa , relation of one to one mapping from one entity to another entity. How much it is different from hibernate. Vijay',NULL,0000,0000,NULL,'',NULL,0,54,'2019-12-26',NULL,13,NULL),
(40,0,48,'RT @dr_ibrahimarifi: @turkialhussini1 صدقت مهندس تركي\n\nوايضاً نحن ننصح دائماً مرضى حساسية الأنف والجيوب الأنفية بالسماح لنور الشمس بالدخول…',NULL,0002,0001,NULL,'48,1','1',0,54,'2019-12-29',NULL,14,'1211350011767857153'),
(41,0,3,'Hola chicos, mi nombre es Avinash, un profesional de la informática que está explorando aplicaciones empresariales con dominio experto en la industria de fabricación, ventas, banca, finanzas y servicios de medios.',NULL,0001,0001,NULL,'48','48',0,54,'2020-01-03',NULL,13,NULL),
(42,0,1,'user , jay26 Nov 2019\nHow to do bidirection mapping in jpa , relation of one to one mapping from one entity to another entity. How much it is different from hibernate.',NULL,0001,0001,NULL,'47','47',0,54,'2020-01-03',NULL,15,NULL),
(43,0,1,'كيفية كتابة وحدة تحكم الراحة في التمهيد الربيع للحصول على تعيين الطلب. هل يمكننا إضافة مورد في طلب المعلمة',NULL,0003,0000,NULL,'1,48,47',NULL,0,54,'2020-01-03',NULL,15,NULL),
(44,0,48,'RT @saudi_umran: تبارك جمعية #العمران للدكتور عبدالعزيز بن جار الله الدغيشم @aldegheishem رئيس مجلس إدارة شعبة أنظمة المعلومات الجغرافية GI…',NULL,0001,0000,NULL,'48',NULL,0,54,'2020-01-03',NULL,14,'1213043455083077634'),
(51,0,5,'اختبار \nTest',NULL,0001,0001,NULL,'48','48',0,54,'2020-01-03',NULL,13,'1213043704568668160'),
(52,0,48,'RT @Kahrabaiat: صورة لتكريمي قبل ايام في #مؤتمر_الشبكات_الذكية من معالي الدكتور خالد السلطان رئيس مدينة الملك عبدالله للطاقة الذرية والمتجد…',NULL,0000,0000,NULL,'',NULL,0,54,'2020-01-04',NULL,14,'1213361882071019520'),
(53,0,48,'RT @Fahad_Allahaim: تكرار الوحدة يعطي انعكاس انيق جدا .. https://t.co/SkTgtckkMi',NULL,0001,0001,NULL,'48','1',0,54,'2020-01-04',NULL,14,'1213323234013319169'),
(54,0,48,'RT @Umran_ID: يسر شعبة التصميم الداخلي بالجمعية السعودية لعلوم العمران فتح الأبواب لعضوية الشعبة وترحب بكل المهتمين في المجال للانضمام من خ…',NULL,0002,0000,NULL,'48,1',NULL,0,54,'2020-01-04',NULL,14,'1213305660743585793'),
(55,0,5,'RT @AlhadabiBadar: تقول المهندسة المعمارية الامريكية جوليا مورغان-العمارة هي فن بصري والمباني تتحدث عن نفسها. تصميمنا الجديد بولاية السويق…',NULL,0001,0001,NULL,'1','1',0,54,'2020-01-03',NULL,13,'1213221021966381059'),
(56,0,5,'RT @AlHulafa: طريقة تركيب شبك اللياسة الفايبر غلاس\n\n• اقوى من الشبك المعدني\n• سهل وسريع التركيب\n• اخطاء اقل في عمليه التركيب\n• يستخدم بين ا…',NULL,0000,0000,NULL,'',NULL,0,54,'2020-01-03',NULL,13,'1213221000919289856'),
(57,0,1,'اسمي أفيناش كومار. أنا أعيش في بنغالورو',NULL,0001,0000,NULL,'1',NULL,0,54,'2020-01-04',NULL,13,NULL),
(63,0,48,'RT @turkialhussini1: @nada___97 الله يبعد عنك الاكتئاب .. بِسْمِ اللهِ أَرْقِيكَ، مِنْ كُلِّ شَيْءٍ يُؤْذِيكَ،',NULL,0001,0000,NULL,'48',NULL,0,54,'2020-01-06',NULL,14,'1214213011885441024'),
(64,0,48,'RT @nada___97: @turkialhussini1 مدري ليش هذي التصاميم على روعتها ودقتها الا انها تجيب لي اكتئاب ?',NULL,0001,0000,NULL,'48',NULL,0,54,'2020-01-06',NULL,14,'1214213004167958532'),
(65,0,48,'سور منزلي نفذت فيه كتلة عرض 40 سم وارتفاع 4 متر وطول 3.4 م وتم تكسيتها من رخام الكلكتا الاسود  .. الدرج والسور بورسلان اسباني نوع واحد بعد قصه مقاسات متعدده الباب ابسط مايكون تويبات حديد 4 سم في 4 سم عرض 1.4 م ونفس ارتفاع السور .. الاضاءه فقط حبتين على السور وحبه على الرخام https://t.co/vwiKnMCzxS',NULL,0001,0000,NULL,'48',NULL,0,54,'2020-01-06',NULL,14,'1214195927042449408'),
(66,0,48,'RT @Fahad_Allahaim: نسال الله التوفيق والسداد في هذه الشعبة وان نقدم انا وزملائي ما هو مفيد لخدمة الوطن فيما يخص بتقنيات البناء https://t.c…',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-01-06',NULL,14,'1214168609775333376'),
(67,0,51,'How to do bidirection mapping in jpa , relation of one to one mapping from one entity to another entity. How much it is different from hibernate.',NULL,0001,0000,NULL,'3',NULL,0,54,'2020-01-06',NULL,13,NULL),
(68,0,51,'\nسور منزلي نفذت فيه كتلة عرض 40 سم وارتفاع 4 متر وطول 3.4 م وتم تكسيتها من رخام الكلكتا الاسود .. الدرج والسور بورسلان اسباني نوع واحد بعد قصه مقاسات متعدده الباب ابسط مايكون تويبات حديد 4 سم في 4 سم عرض 1.4 م ونفس ارتفاع السور .. الاضاءه فقط حبتين على السور وحبه على الرخام',NULL,0002,0000,NULL,'3,1',NULL,0,54,'2020-01-07',NULL,13,NULL),
(74,0,26,'asd',NULL,0000,0000,NULL,'',NULL,0,54,'2020-01-20',NULL,13,NULL),
(75,0,1,'',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-01-24',NULL,15,NULL),
(76,0,1,'هنا هو الجدول الزمني للاختبار وأنها تعمل بشكل جيد.',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-01-24',NULL,15,NULL),
(77,0,1,'في العادة، يقوم المرشحين بالقاء خطبة قصيرة قبل التصويت',NULL,0001,0000,NULL,'1',NULL,0,54,'2020-01-24',NULL,15,NULL),
(78,0,1,'بالقاء خطبة قصيرة قبل التصويت بما أن بورت سوف يثبت لكم أن الخطب مملة',NULL,0000,0000,NULL,'',NULL,0,54,'2020-01-24',NULL,15,NULL),
(79,0,1,'Delhi assembly election is on 8th Feb. Keep count for your valuable votes.',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-01-25',NULL,15,NULL),
(80,0,1,'Test',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-01-25',NULL,15,NULL),
(81,0,1,'اببااتتوو الللاننعفبىاتنننن',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-01-25',NULL,15,NULL),
(86,0,1,'Failure will never overtake me if my determination to succeed is strong enough',NULL,0002,0001,NULL,'1,51','1',0,54,'2020-01-28',NULL,16,NULL),
(87,0,26,'26_56_9861db7e-8b1f-4e7a-bbce-0e453041e74a-trailer_hd.mp4',NULL,0000,0000,NULL,NULL,NULL,0,56,'2020-01-29',NULL,13,NULL),
(88,0,1,'Knowing is not enough, we must apply. Willing is not enough, we must do.',NULL,0000,0002,NULL,'','1,47',0,54,'2020-01-29',NULL,16,NULL),
(89,0,1,'Knowing is not enough, we must apply',NULL,0001,0001,NULL,'1','1',0,54,'2020-01-29',NULL,16,NULL),
(92,0,1,'1_58_7fa74d87-98d4-4110-9e16-de0faae74051-peripherals.jpg',NULL,0000,0000,NULL,'',NULL,0,58,'2020-01-31',NULL,16,NULL),
(93,0,1,'1_58_e3d8f975-2feb-48f1-8f40-121b29d03ce5-images.jpg',NULL,0000,0000,NULL,NULL,NULL,0,58,'2020-01-31',NULL,16,NULL),
(95,0,1,'1_58_dff5af3e-325a-46cb-9406-31bb443f607d-5cc230d9c3a7c15db8365bd5-1136-853.jpg',NULL,0002,0001,NULL,'1,47','1',0,58,'2020-01-31',NULL,16,NULL),
(111,0,1,'1_58_82885be4-7c0b-44bc-b304-275938ea9dc7-thoughtPF_imageb844a205b331be4dd32fd0472af96261.jpg',NULL,0000,0000,NULL,NULL,NULL,0,58,'2020-01-31',NULL,16,NULL),
(112,0,1,'1_55_e0b49b98-4c17-4360-b38c-2e7e7b9f5761-thoughtPF_audioTujhe Kitna Chahein Aur Hum | Kabir Singh | Jubin Nautiyal Live | Mithoon | Thomso 2019 | IIT Roorke',NULL,0000,0000,NULL,NULL,NULL,0,55,'2020-01-31',NULL,16,NULL),
(113,0,1,'Abcd check',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-01-31',NULL,16,NULL),
(114,0,1,'1_58_fd3265c9-3cb1-4068-abd3-a6c24668dbc7-thoughtPF_imageimage-40cfc759-4ae8-41f6-9b94-ecba056123f3.jpg',NULL,0001,0001,NULL,'1','1',0,58,'2020-01-31',NULL,16,NULL),
(115,0,1,'1_55_e0f02e08-8f95-4164-b6f0-e92bd4fc0960-thoughtPF_audioTujhe Kitna Chahein Aur Hum | Kabir Singh | Jubin Nautiyal Live | Mithoon | Thomso 2019 | IIT Roorke',NULL,0000,0000,NULL,NULL,NULL,0,55,'2020-01-31',NULL,16,NULL),
(118,0,1,'1_58_180d1861-b0e4-46be-8132-f82dc5af665d-thoughtPF_imageimage-e64e21fb-a7f1-4e9c-8056-d94fd7228165.jpg',NULL,0001,0000,NULL,'1',NULL,0,58,'2020-01-31',NULL,16,NULL),
(119,47,1,'Test ask question',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-02-03',NULL,16,NULL),
(124,1,48,'What\'s your name? ',NULL,0001,0000,NULL,'1',NULL,0,54,'2020-02-03',NULL,14,NULL),
(125,1,2,'What do you have? ',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-02-03',NULL,13,NULL),
(126,1,51,'Ghtdhfijgfjy',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-02-04',NULL,13,NULL),
(127,1,51,'Asdf',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-02-08',NULL,13,NULL),
(130,47,2,'Test ask question',NULL,0000,0000,NULL,NULL,NULL,0,58,'2020-02-10',NULL,16,NULL),
(131,47,2,'Test ask question',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-10',NULL,16,NULL),
(132,47,1,'Test ask question',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-10',NULL,16,NULL),
(133,47,2,'Test ask question second time','Test give Answer',0000,0000,NULL,NULL,NULL,0,59,'2020-02-10',NULL,16,NULL),
(134,57,2,'Ughyyy',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-02-10',NULL,13,NULL),
(135,1,48,'Ask',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-11',NULL,14,NULL),
(136,1,48,'Question for free',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-11',NULL,14,NULL),
(137,1,2,'I\'m asking free question to jay user ',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-02-11',NULL,13,NULL),
(138,47,2,'Test ask question second time',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-11',NULL,16,NULL),
(139,1,2,'Ask questions ',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-11',NULL,13,NULL),
(140,1,2,'Ask questions 124',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-11',NULL,13,NULL),
(141,1,2,'Ask 12345',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-11',NULL,13,NULL),
(142,0,1,'Great color mixing activities for kids, including how to mix paint, color science ... FREE printable book activity for toddlers to go along with',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-02-11',NULL,12,NULL),
(143,1,51,'This guide walks you through the process of building an application that uses Spring Data JPA to store and retrieve data in a relational database.',NULL,0000,0000,NULL,NULL,NULL,0,54,'2020-02-11',NULL,13,NULL),
(144,51,26,'Asking question here',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-12',NULL,13,NULL),
(145,1,2,'Asking free question\n',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-12',NULL,13,NULL),
(146,51,1,'Hi jaynt','Hi Avinash',0000,0000,NULL,NULL,NULL,0,59,'2020-02-14',NULL,16,NULL),
(147,0,48,'RT @Eng_A_C: الان افضل وقت لصيانة المكيفات لأهميتها في:\nتقليل الاعطال في فترة الصيف\nوتقليل استهلاك الكهرب\nوالاستفادة من كفاءة المكيف بالكام…',NULL,0000,0000,NULL,NULL,NULL,0,01,'2020-02-22',NULL,14,'1231102063205134336'),
(148,1,48,'ا',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-22',NULL,14,NULL),
(149,1,26,'االب',NULL,0000,0000,NULL,NULL,NULL,0,59,'2020-02-22',NULL,13,NULL),
(150,0,1,'مجرد تجربه للتايم لاين .....\n\nفيه حاجات لازم تتضبط مثل ارسال السوال بوب اوت كتابه فقط ولها حد اعلى ?',NULL,0001,0000,NULL,'1',NULL,0,54,'2020-02-25',NULL,12,NULL),
(151,0,1,'',NULL,0000,0000,NULL,NULL,NULL,0,58,'2020-03-07',NULL,12,NULL),
(152,0,1,'',NULL,0000,0000,NULL,NULL,NULL,0,58,'2020-03-07',NULL,12,NULL),
(153,0,1,'',NULL,0000,0000,NULL,NULL,NULL,0,58,'2020-03-07',NULL,12,NULL),
(154,0,51,'51_58_c816f555-b982-4833-9590-be730d788139-thoughtPF_imageimage-8a6f9c33-3825-4a73-81a8-432d56befb97.jpg',NULL,0000,0000,NULL,NULL,NULL,0,58,'2020-03-07',NULL,13,NULL);

/*Table structure for table `topics` */

DROP TABLE IF EXISTS `topics`;

CREATE TABLE `topics` (
  `TOPICS_ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `TOPICS_ARTICLE` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `LIKE_COUNT` int(4) unsigned zerofill DEFAULT NULL,
  `DISLIKE_COUNT` int(4) unsigned zerofill DEFAULT NULL,
  `SHARE_URL` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `LIKE_USER_ID` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `DISLIKE_USER_ID` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `TOPICS_TYPE` int(2) unsigned zerofill DEFAULT NULL,
  `CREATED_ON` date NOT NULL,
  `CATAGORY_ID` int(2) NOT NULL DEFAULT '0',
  `COMMENTS_COUNT` int(2) DEFAULT NULL,
  `HASHTAG` int(11) DEFAULT NULL,
  `KEYWORD` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `USER_DISPLAY_NAME` varchar(100) COLLATE utf8_bin NOT NULL,
  `IS_DELETED` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`TOPICS_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `topics` */

insert  into `topics`(`TOPICS_ID`,`USER_ID`,`TOPICS_ARTICLE`,`LIKE_COUNT`,`DISLIKE_COUNT`,`SHARE_URL`,`LIKE_USER_ID`,`DISLIKE_USER_ID`,`TOPICS_TYPE`,`CREATED_ON`,`CATAGORY_ID`,`COMMENTS_COUNT`,`HASHTAG`,`KEYWORD`,`USER_DISPLAY_NAME`,`IS_DELETED`) values 
(1,1,'AEM CONTENT CMS Topics',0000,0000,NULL,NULL,NULL,00,'2020-10-19',13,0,2,NULL,'Avinash K',0),
(2,1,'Alfresco CONTENT CMS Topics',0000,0000,NULL,NULL,NULL,00,'2020-10-19',13,0,2,NULL,'Avinash K',0),
(3,1,'Magnolia ECM WEB CONTENT CMS',0000,0000,NULL,NULL,NULL,00,'2020-10-19',13,0,2,NULL,'Avinash K',0);

/*Table structure for table `transaction` */

DROP TABLE IF EXISTS `transaction`;

CREATE TABLE `transaction` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) DEFAULT NULL,
  `SHOP_ID` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `PAYMENT_MODE` int(30) DEFAULT NULL,
  `AMOUNT` int(20) DEFAULT NULL,
  `CREATED_ON` date DEFAULT NULL,
  `TRANSACTION_ID` int(20) DEFAULT NULL,
  `USER_TYPE` int(30) DEFAULT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  `IS_ACTIVE` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `transaction` */

insert  into `transaction`(`ID`,`USER_ID`,`SHOP_ID`,`PAYMENT_MODE`,`AMOUNT`,`CREATED_ON`,`TRANSACTION_ID`,`USER_TYPE`,`IS_DELETED`,`IS_ACTIVE`) values 
(1,232,'Avi23',324,312000,'2021-04-01',1,80,0,1),
(2,34353,'Avi23',43534,435,'2021-03-11',10,21322,0,1),
(3,0,'3434e',0,0,NULL,10,0,0,0),
(4,12312,'23323pri',324,3423,NULL,5555,80,0,0),
(5,12312,'23323avi',324,3423,NULL,332332,33233,0,0),
(6,12312,'myshop12',324,3423,'2021-04-03',332332,33233,0,0),
(7,12312,'myshop420',324,3423,'2021-04-03',332332,33233,0,0),
(8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMAIL_ID` varchar(50) CHARACTER SET latin1 NOT NULL,
  `F_NAME` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `USER_TYPE` int(11) NOT NULL,
  `L_NAME` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `INITIALS` varchar(15) CHARACTER SET latin1 DEFAULT NULL,
  `ACTIVE_IND` tinyint(1) NOT NULL DEFAULT '0',
  `IS_DELETED` tinyint(1) NOT NULL DEFAULT '1',
  `DOB` datetime DEFAULT NULL,
  `LAST_LOGIN_DATE` datetime DEFAULT NULL,
  `PWD` varchar(40) CHARACTER SET latin1 DEFAULT NULL,
  `TOKEN` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `WALLET_BALANCE` int(5) DEFAULT '0',
  `BANK_DETAILS` int(5) DEFAULT '0',
  `ADDRESS_DETAILS` int(5) DEFAULT '0',
  `ARTICLE_DETAILS` int(5) DEFAULT '0',
  `MOBILE_NUMBER` varchar(20) COLLATE utf8_bin DEFAULT '0',
  `CITY` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `FOLLOW_COUNT` int(5) DEFAULT '0',
  `FOLLOW` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `FOLLOWING` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `FOLLOWING_COUNT` int(4) DEFAULT '0',
  `BIOGRAPHY` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `CREATED_ON` datetime DEFAULT NULL,
  `NAME` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `OTP` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `WISH_LIST` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `user` */

insert  into `user`(`ID`,`EMAIL_ID`,`F_NAME`,`USER_TYPE`,`L_NAME`,`INITIALS`,`ACTIVE_IND`,`IS_DELETED`,`DOB`,`LAST_LOGIN_DATE`,`PWD`,`TOKEN`,`WALLET_BALANCE`,`BANK_DETAILS`,`ADDRESS_DETAILS`,`ARTICLE_DETAILS`,`MOBILE_NUMBER`,`CITY`,`FOLLOW_COUNT`,`FOLLOW`,`FOLLOWING`,`FOLLOWING_COUNT`,`BIOGRAPHY`,`CREATED_ON`,`NAME`,`OTP`,`WISH_LIST`) values 
(1,'jaykrs@in.com','Avinash',2,'Kumar','Mr',1,0,'2010-01-12 00:00:00','2021-02-28 23:49:44','Welcome@0',NULL,38,0,0,0,'09126756577','Mysore',2,'5,2',NULL,0,NULL,NULL,NULL,'1234',NULL),
(2,'jay@inc.com','jay',2,'user','Mr',1,0,'2020-01-02 00:00:00','2020-01-07 06:09:57','Welcome@0',NULL,45,0,0,0,'9716529094','Patna',-28,'51',NULL,0,NULL,NULL,NULL,'1234',NULL),
(3,'jcykrs@indcom.com','Jatin',2,'Consultant','Mr',1,0,'2020-01-15 00:00:00','2020-01-07 10:13:31','Welcome@0',NULL,0,0,0,0,'0123456789','Ramnagar',1,'1',NULL,0,NULL,NULL,NULL,'1234',NULL),
(4,'vikash@consultant.com','Vikash',2,'Consultant','Mr',1,0,'2019-11-02 00:00:00','2019-11-02 16:18:26','Welcome@0',NULL,0,0,0,0,'0',NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(5,'javeed@askert.com','Javed Ahmad',2,'Consultant','Mr',1,0,'2019-11-02 00:00:00',NULL,'Welcome@0',NULL,0,0,0,0,'0',NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(26,'avi1@in.com','Avinash',2,'Kumar',NULL,1,0,NULL,'2020-03-11 12:25:48','Welcome@0',NULL,0,0,0,0,NULL,'Ramnagar',-19,'51',NULL,0,NULL,NULL,NULL,'1234',NULL),
(47,'sulaiman.user@gmail.com','sulaiman',2,'user',NULL,1,0,'1983-02-12 00:00:00','2020-03-14 10:08:56','Welcome@0',NULL,40,0,0,0,'+966562300010','Saudi Arabia',1,'1',NULL,0,NULL,NULL,NULL,'1234',NULL),
(48,'sulaiman.consultant@gmail.com','sulaiman',2,'consultant',NULL,1,0,'2019-03-13 00:00:00','2020-01-21 12:00:35','Welcome@0',NULL,0,0,0,0,'+966562300010','Bengaluru',0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(49,'admin@thoughtpf.com','admin',2,'thoughtpf',NULL,1,0,NULL,'2020-02-25 06:37:25','Welcome@0',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(51,'avi@in.com','Avinash ',2,'Kumar ',NULL,1,0,'2019-02-03 00:00:00','2021-04-09 14:35:38','Welcome@0','7379c72f-e26c-49c6-bac0-1c303d3478ac-51',0,0,0,0,'7903032346','Bengaluru',1,'1',NULL,0,NULL,NULL,NULL,'1234',NULL),
(57,'avi2@in.com','Avinash',2,'Tiwari',NULL,1,0,NULL,'2020-02-10 22:33:28','Welcome@0',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(58,'','',2,NULL,NULL,0,0,NULL,NULL,'',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(59,'Akash@gmail.com','Akash',2,'kumar',NULL,0,0,NULL,NULL,'Welcome@0',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(60,'Akask@gmail.com','Akash',2,'kumar',NULL,0,0,NULL,NULL,'Welcome@0',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(61,'Vikas@gmail.com','Vikas',2,'kumar',NULL,0,0,NULL,NULL,'Welcome@0',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(62,'avinash@gmail.com','avinash',2,'kumar',NULL,0,0,NULL,NULL,'Welcome@0',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(63,'Vinod@gmail.com','Vinod',2,NULL,NULL,0,0,NULL,NULL,'Welcome@0',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(64,'Kiran@gmail.com','Kiran',2,'Kumar ',NULL,0,0,NULL,NULL,'Welcome@0',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(65,'Vyuvb@gmail.com','Hc8hh oh ',2,'H it g  h8 ',NULL,0,0,NULL,NULL,'Cugug8ig',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(66,'Vijay@gmail.com','Vijay',2,'Kumar',NULL,1,0,NULL,'2020-02-01 09:18:15','Welcome@0',NULL,0,0,0,0,NULL,NULL,0,'',NULL,0,NULL,NULL,NULL,'1234',NULL),
(67,'avi3@in.com','Avi',2,'Kumar',NULL,0,0,NULL,NULL,'Welcome@0',NULL,0,0,0,0,NULL,NULL,0,NULL,NULL,0,NULL,NULL,NULL,'1234',NULL),
(68,'Kishor@gmail.com','Kishor',2,'Kumar',NULL,0,0,NULL,NULL,'Welcome@0',NULL,0,0,0,0,NULL,NULL,0,NULL,NULL,0,NULL,NULL,NULL,'1234',NULL),
(69,'vermaman03@gmail.com','Aman',2,'Verma',NULL,0,0,NULL,NULL,'@man7703944911',NULL,0,0,0,0,NULL,NULL,0,NULL,NULL,0,NULL,NULL,NULL,'1234',NULL),
(70,'atishdipankar99@gmail.com','Aman',2,'Verma',NULL,0,0,NULL,NULL,'12345678',NULL,0,0,0,0,NULL,NULL,0,NULL,NULL,0,NULL,NULL,NULL,'1234',NULL),
(71,'Punit.srivastava@yahoo.com','PUNIT',2,'S.',NULL,0,0,NULL,NULL,'12345678',NULL,0,0,0,0,NULL,NULL,0,NULL,NULL,0,NULL,NULL,NULL,'1234',NULL),
(72,'jykrs@in.com',NULL,2,NULL,'',0,0,'1900-01-01 00:00:00','1900-01-01 00:00:00','',NULL,0,0,0,0,'','',0,NULL,NULL,0,'','2021-03-23 17:43:44','Avinash','1234',NULL),
(73,'jaykrs@ina.com',NULL,2,NULL,'',0,0,'1900-01-01 00:00:00','1900-01-01 00:00:00','',NULL,0,0,0,0,'','',0,NULL,NULL,0,'','2021-03-24 12:29:51','','1234',NULL),
(74,'9716529094','jay',0,'user',NULL,0,1,NULL,NULL,'Welcome@0',NULL,0,0,0,0,NULL,NULL,0,NULL,NULL,0,NULL,'2021-04-09 10:58:11','jay','1234',NULL),
(75,'7739031245','Prince',0,'Kumar',NULL,0,1,NULL,NULL,'Milaan',NULL,0,0,0,0,NULL,NULL,0,NULL,NULL,0,NULL,'2021-04-09 13:28:06','Prince','1234',NULL),
(76,'7739031245','Prince',0,'Kumar',NULL,0,1,NULL,NULL,'Milaan',NULL,0,0,0,0,NULL,NULL,0,NULL,NULL,0,NULL,'2021-04-09 13:28:13','Prince','1234',NULL),
(77,'7739031245','Prince',0,'Kumar',NULL,0,1,NULL,NULL,'Milaan',NULL,0,0,0,0,NULL,NULL,0,NULL,NULL,0,NULL,'2021-04-09 13:28:16','Prince','1234',NULL),
(78,'7739031245','Prince',0,'Kumar',NULL,0,1,NULL,NULL,'Milaan',NULL,0,0,0,0,NULL,NULL,0,NULL,NULL,0,NULL,'2021-04-09 13:28:18','Prince','1234',NULL),
(79,'','Prince',0,'Kumar','',0,1,'1900-01-01 00:00:00','1900-01-01 00:00:00','Milaan','',0,0,0,0,'7739031245','',0,NULL,NULL,0,'','2021-04-09 13:40:51','Prince','1234',''),
(80,'','Prince',2,'Kumar','',0,1,'1900-01-01 00:00:00','1900-01-01 00:00:00','Milaan','',0,0,0,0,'773903145','',0,NULL,NULL,0,'','2021-04-09 14:05:09','Prince','1234',''),
(81,'','Prince',2,'Kumar','',0,1,'1900-01-01 00:00:00','1900-01-01 00:00:00','Milaan','',0,0,0,0,'773903170','',0,NULL,NULL,0,'','2021-04-09 14:08:02','Prince','1234',''),
(85,'','Aniket ',2,'Kumar','',1,0,'1900-01-01 00:00:00','2021-04-13 14:47:14','MilaanITProjects','6319b4c3-3b52-4bd4-813f-026ee55ab2e0-85',0,0,0,0,'9835664127','',0,NULL,NULL,0,'','2021-04-09 14:29:25','Aniket ','1234','');

/*Table structure for table `user_device` */

DROP TABLE IF EXISTS `user_device`;

CREATE TABLE `user_device` (
  `ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `DEVICE_ID` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `user_device` */

/*Table structure for table `user_device_id_mapping` */

DROP TABLE IF EXISTS `user_device_id_mapping`;

CREATE TABLE `user_device_id_mapping` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) DEFAULT NULL,
  `DEVICE_ID` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `APNS_TOKEN_ID` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `user_device_id_mapping` */

insert  into `user_device_id_mapping`(`ID`,`USER_ID`,`DEVICE_ID`,`APNS_TOKEN_ID`) values 
(1,1,'4345-tr45-23ytr-34ytre-54ttt','55555'),
(2,2,'44444444','ttttt444'),
(3,0,NULL,NULL),
(4,26,'qwerty1234asdf12',NULL),
(5,1,'4345-tr45-23ytr-34ytre-5422w',NULL),
(6,51,'abc12-def34-ghi56',NULL),
(7,51,'3444344jkojijkj',NULL),
(8,51,'25387236981',NULL),
(9,51,'254336547567',NULL),
(10,51,'25dsfgsdg242342',NULL),
(11,51,'45645fg55445thrt',NULL),
(12,51,'aakdhnjfkfsdiuhgsdhfbshdfbshjdfbjhskbf',NULL),
(13,51,'12313452453',NULL),
(14,51,'1231gdfgdfgdfh3452453',NULL),
(15,51,'123assdffqwer1213',NULL),
(16,85,'123assdffqwer123',NULL),
(17,85,'1231gdfgdfgdfh3452453',NULL),
(18,85,'9942453d797eb694',NULL);

/*Table structure for table `user_role` */

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `CUSTOMER` tinyint(1) DEFAULT NULL,
  `CONSULTANT` tinyint(1) DEFAULT NULL,
  `ADMIN` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_role` */

/*Table structure for table `work` */

DROP TABLE IF EXISTS `work`;

CREATE TABLE `work` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `ABSENT` int(2) DEFAULT NULL,
  `PRESENT` int(2) DEFAULT NULL,
  `BONUS` float DEFAULT NULL,
  `CREATED_ON` date DEFAULT NULL,
  `ADVANCE_SALARY` float DEFAULT NULL,
  `SALARY` float DEFAULT NULL,
  `SALARY_TYPE` int(10) DEFAULT NULL,
  `LEAVE_FROM` date DEFAULT NULL,
  `LEAVE_TO` date DEFAULT NULL,
  `LEAVE_TYPE` int(10) DEFAULT NULL,
  `INCENTIVE` float DEFAULT NULL,
  `ATTENDANCE` varchar(12) CHARACTER SET utf8mb4 DEFAULT NULL,
  `EMPLOYEE_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `SHOP_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `IS_DELETED` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `work` */

insert  into `work`(`ID`,`ABSENT`,`PRESENT`,`BONUS`,`CREATED_ON`,`ADVANCE_SALARY`,`SALARY`,`SALARY_TYPE`,`LEAVE_FROM`,`LEAVE_TO`,`LEAVE_TYPE`,`INCENTIVE`,`ATTENDANCE`,`EMPLOYEE_ID`,`SHOP_ID`,`IS_ACTIVE`,`IS_DELETED`) values 
(1,1,8,300000,'2021-03-10',2000,89089,998,'2021-03-13','2021-03-13',98089,3565640,'ghfg','man22','Avi23',1,0),
(2,2,3,234342,'2021-03-09',43543,345,4343,'2021-03-05','2021-03-11',443,434,'fghgh','tt','dff4',1,0),
(3,3,4,98798,'2021-03-10',78968,78678,767,'2021-03-12','2021-03-12',565,4545,'try','man221','tyt55',1,0),
(4,5,50,8000,NULL,55000,6000,1,NULL,NULL,2,3565640,'Absent','tt','avinash55',1,0),
(5,5,50,8000,NULL,55000,6000,1,NULL,NULL,2,3565640,'Absent','prince545','avinash55',1,0),
(6,1,8,5000,NULL,2000,89089,0,NULL,NULL,98089,3565640,'ghfg','Shivam44','shivam45',1,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
