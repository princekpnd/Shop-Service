package com.shop.shopservice.constants;

/**
 * @author Avinash
 *
 */
public class ArticleConstants {

}
