package com.shop.shopservice.ctd;

/**
 * @author Avinash
 *
 */
public class ProductCatagory {

}
