package com.shop.shopservice.mservice;

/**
 * @author Avinash
 *
 */
public interface IArticleMService {

}
