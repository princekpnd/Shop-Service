package com.shop.shopservice.service;

/**
 * @author Avinash
 *
 */
public interface IArticleService {

}
