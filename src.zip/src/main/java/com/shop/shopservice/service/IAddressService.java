package com.shop.shopservice.service;
import java.util.List;
import com.shop.shopservice.entity.Address;
public interface IAddressService {
	
	List<Address> getAllAddress();
	public List<Address> getAddressByShopId(String shopId);
	public boolean addressExists(String shopId);
	public boolean createAddress(Address address);
	public Address getAddress(int id);
	public boolean updateAddress(Address address);

}
