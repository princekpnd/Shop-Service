package com.shop.shopservice.service;

import java.util.List;

import com.shop.shopservice.entity.Cart;
import com.shop.shopservice.entity.ProductList;

public interface ICartService {

	List<Cart> getAllCart();

	public Cart getCart(int cartId);

	List<Cart> getCartByUserId(String userId, String shopId, boolean orderStatus);

	public List<Cart> getCartForUserByShopId(String shopId);

	public boolean updateCart(Cart cart);
	
	public ProductList getProductByProductId(String productId, int cartId);
	
	public void updateProductList(ProductList plId, float productQuantity);

	public boolean cartExists(String userId, String shopId, boolean orderStatus);

	public boolean createCart(Cart cart);
}
