package com.shop.shopservice.service;

import java.util.List;

import com.shop.shopservice.entity.User;
import com.shop.shopservice.entity.UserDeviceID;

public interface IUserService {

	public boolean createUserSignup(User user);
	public boolean updateUser(User user);
	public User getUser(int userId);
	public void activateUser(User user);
	public boolean createUser(String userId, String emailId, String name, String pwd);
	public boolean usersExists(String mobileNo) ;
	public User loginUser(String emailId, String pwd);
	public User findUser(String userId, String emailId);
	public User loginCasUser(String userId, String emailId);
	User validateUserByDeviceId(String deviceId);
	public User getUsersByEmailId(String emailId);
	public User sendOtp(String mobileNo);
	public void deleteUserDevice(UserDeviceID ud);
	public User getUserByOtp(String mobileNo, String otp);
//	int viewWalletBalance(int userId);
//	boolean updateWalletBalance(int userId, int amount);
	List<User> getAllUsers(int count);
//	public User loginAdminUser(String emailId, String pwd);
//	public void followConsultantByUser(User consultant, Integer userId);
}
