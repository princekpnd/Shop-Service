package com.shop.shopservice.email;

/**
 * @author Avinash
 *
 */
public interface IEmailUtilility {

}
