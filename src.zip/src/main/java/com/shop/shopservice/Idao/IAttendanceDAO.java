package com.shop.shopservice.Idao;

import java.util.List;
import com.shop.shopservice.entity.Attendance;

public interface IAttendanceDAO {
	
	List<Attendance> getAllAttendance();
	List<Attendance> getByEmployeeId(String employeeId);
	List<Attendance> getByShopId(String shopId);
	 boolean attendanceExists(String employeeId);
	 void addAttendance(Attendance attendance);
	 void updateAttendance( Attendance  attendance);
	 Attendance  getAttendanceByEmployeeId(String employeeId);
}
