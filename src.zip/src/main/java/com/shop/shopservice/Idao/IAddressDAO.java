package com.shop.shopservice.Idao;
import java.util.List;
import com.shop.shopservice.entity.Address;
public interface IAddressDAO {
	
	List<Address> getAllAddress();
	List<Address> getAddressByShopId(String shopId);
	 boolean addressExists(String shopId);
	 void addAddress(Address address);
	 Address getAddressById(int id);
	 void updateAddress(Address address);

}
