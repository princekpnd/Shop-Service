package com.shop.shopservice.Idao;

import java.util.List;
import com.shop.shopservice.entity.Product;
public interface IProductDAO {
	
	List<Product> getAllProduct();
	List<Product> getAllProductForUser();
	Product getProductById(int productId);
	List<Product> getProductByName(String name);
	Product getProductByCategory(int category);
	List<Product> getProductByShopId(String shopId);
	List<Product> getProductForUserByShopId(String shopId);
	List<Product> getProductByShopIdForCategory(String shopId, int category);
	List<Product> getProductByBrandName(int brand);
	void updateProduct(Product product);
	boolean productExists(String shopId);
	void addProduct(Product product);

}
