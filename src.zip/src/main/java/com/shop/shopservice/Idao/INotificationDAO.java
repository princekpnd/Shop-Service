package com.shop.shopservice.Idao;

import java.util.List;

import com.shop.shopservice.entity.Notification;

public interface INotificationDAO {

	public List<Notification> getAllNotification(int count);
	public List<Notification> getAllNotificationOnCatagory(int catagory);
	public List<Notification> getAllNotificationOnSubCatagory(List<Integer> subCatagoryList);
	public void createNotification(Notification notification);
	public void updateNotification(Notification notification);
	public Notification getNotificationById(long notificationId);
	public List<Notification> getNotificationByUserId(int userId);
	
}
