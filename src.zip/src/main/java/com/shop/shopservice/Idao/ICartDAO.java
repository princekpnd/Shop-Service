package com.shop.shopservice.Idao;

import java.util.List;
import com.shop.shopservice.entity.Cart;
import com.shop.shopservice.entity.ProductList;
public interface ICartDAO {
	List<Cart> getAllCart();
	Cart getCartById(int cartId);
	ProductList getProductByProductId(String productId, int cartId);
	public void updateProductList(ProductList plId, float productQuantity);
	List<Cart> getCartForUserByShopId(String shopId);
	List<Cart> getCartByUserId(String userId, String shopId, boolean orderStatus);
	void updateCart(Cart cart);
	boolean cartExists(String userId, String shopId, boolean orderStatus);
	void addCart(Cart cart);


}
