package com.shop.shopservice.mq;

/**
 * @author Avinash
 *
 */
public interface IArticleMessageQueue {

}
