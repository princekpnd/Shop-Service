package com.shop.shopservice.utils;

/**
 * @author Avinash
 *
 */
public class ArticleUtils {

}
