/**
 * 
 */
package com.shop.shopservice.licensee;

import com.shop.shopservice.entity.ManagedObject;

/**
 * @author Avinash
 *
 */
public interface ILicensee {

	public boolean isValidLicensee(ManagedObject managedObject);
}
