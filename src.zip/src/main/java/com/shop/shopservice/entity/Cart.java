package com.shop.shopservice.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;

@Entity
@Table(name = "CART")
@NamedQueries({ @NamedQuery(name = "Cart.findAll", query = "SELECT cr FROM Cart cr"),
		@NamedQuery(name = "Cart.findByOrderActiveUserId", query = "SELECT cr FROM Cart cr WHERE cr.userId = :userId and cr.shopId = :shopId and cr.orderStatus = :orderStatus"),
		@NamedQuery(name = "Cart.findCartForUserByShopId", query = "SELECT cr FROM Cart cr WHERE cr.shopId= :shopId")

})

public class Cart implements Serializable {

	private static final long serialVersionUID = 1385794955661915701L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false)
	private int cartId;

	@Column(name = "USER_ID", nullable = false)
	private String userId;

	@Column(name = "SHOP_ID", nullable = false)
	private String shopId;

	@Column(name = "TRANSACTION_ID", nullable = false)
	private String transactionId;

	@Column(name = "CREATED_ON", nullable = false)
	private Date createdOn;

	@Column(name = "GST_AMOUNT", nullable = false)
	private float gstAmount;

	@Column(name = "TOTAL_AMOUNT", nullable = false)
	private float totalAmount;

	@Column(name = "PAID", nullable = false)
	private float paid;

	@Column(name = "DUES", nullable = false)
	private float dues;

	@Column(name = "IS_ACTIVE", nullable = false)
	private boolean isActive;

	@Column(name = "IS_DELETED", nullable = false)
	private boolean isDeleted;

	@Column(name = "ORDER_STATUS", nullable = false)
	private boolean orderStatus;

	@OneToMany(mappedBy="cart",cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private List<ProductList> productList;

	public Cart() {
		super();
	}
	
	public Cart(String userId, String shopId) {
		this.userId = userId;
		this.shopId = shopId;
	}

	/**
	 * @return the cartId
	 */
	public int getCartId() {
		return cartId;
	}

	/**
	 * @param cartId the cartId to set
	 */
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the shopId
	 */
	public String getShopId() {
		return shopId;
	}

	/**
	 * @param shopId the shopId to set
	 */
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the gstAmount
	 */
	public float getGstAmount() {
		return gstAmount;
	}

	/**
	 * @param gstAmount the gstAmount to set
	 */
	public void setGstAmount(float gstAmount) {
		this.gstAmount = gstAmount;
	}

	/**
	 * @return the totalAmount
	 */
	public float getTotalAmount() {
		return totalAmount;
	}

	/**
	 * @param totalAmount the totalAmount to set
	 */
	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}

	/**
	 * @return the paid
	 */
	public float getPaid() {
		return paid;
	}

	/**
	 * @param paid the paid to set
	 */
	public void setPaid(float paid) {
		this.paid = paid;
	}

	/**
	 * @return the dues
	 */
	public float getDues() {
		return dues;
	}

	/**
	 * @param dues the dues to set
	 */
	public void setDues(float dues) {
		this.dues = dues;
	}

	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the isDeleted
	 */
	public boolean isDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the orderStatus
	 */
	public boolean isOrderStatus() {
		return orderStatus;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrderStatus(boolean orderStatus) {
		this.orderStatus = orderStatus;
	}

	/**
	 * @return the productList
	 */
	public List<ProductList> getProductList() {
		return productList;
	}

	/**
	 * @param productList the productList to set
	 */
	public void setProductList(List<ProductList> productList) {
		this.productList = productList;
	}

}
