   package com.shop.shopservice.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "PRODUCT_LIST")

@NamedQueries({
//	@NamedQuery(name="ProductList.fetchProductListDetailsByCartId",query="select cr from ProductList cr where cr.cartId LIKE :cartId"),
	@NamedQuery(name="ProductList.fetchProductById",query="select pl from ProductList pl where pl.productId LIKE :productId and pl.cart.cartId = :cartId"),
//	@NamedQuery(name="ProductList.updateId",query="UPDATE ProductList SET cartId = ? where id = ?"),
//	@NamedQuery(name="ProductList.getCartID", query = "select cr.userId from ProductList cr " +
//	" where cr.cart.productId = :productId and cr.userId !=null")
})
public class ProductList  implements Serializable{
	private static final long serialVersionUID = 1385794955661915701L;

	
	//@NotNull
		@ManyToOne(fetch = FetchType.LAZY, optional = false)
        @JoinColumn(name = "CART_ID", nullable = false)
	    @OnDelete(action = OnDeleteAction.CASCADE)
        @JsonIgnore
		private Cart cart;
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "ID", nullable = false)
		private int id;
		
	@Column(name ="SHOP_ID" ,nullable =false)
	private String shopId;
	
	@Column(name ="USER_ID",nullable =false)
	private String userId;
	
	@Column(name = "PRODUCT_ID",nullable =false)
	private String productId;
	
	@Column(name ="PRODUCT_NAME",nullable =false)
	private String productName;
	
//	@Column(name ="CART_ID",nullable =false)
//	private int cartId;
	
	@Column(name ="CREATED_ON",nullable =false)
	private Date createdOn;
	
	
	
	@Column(name ="PRODUCT_QUANTITY",nullable =false)
	private float productQuantity;
	
	@Column(name ="PRICE",nullable =false)
	private float price;
	
	@Column(name ="IS_ACTIVE",nullable =false)
	private boolean isActive;
	
	@Column(name ="IS_DELETED",nullable =false)
	private boolean isDeleted;
	
//	@Column(name ="ORDER",nullable =false)
//	private int order;
	
	@Column(name ="OFFER",nullable =false)
	private int offer;
	
	public ProductList() {
		super();
	}
	

	/**
	 * @return the cart
	 */
	public Cart getCart() {
		return cart;
	}

	/**
	 * @param cart the cart to set
	 */
	public void setCart(Cart cart) {
		this.cart = cart;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the shopId
	 */
	public String getShopId() {
		return shopId;
	}

	/**
	 * @param shopId the shopId to set
	 */
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the productQuantity
	 */
	public float getProductQuantity() {
		return productQuantity;
	}

	/**
	 * @param productQuantity the productQuantity to set
	 */
	public void setProductQuantity(float productQuantity) {
		this.productQuantity = productQuantity;
	}

	/**
	 * @return the price
	 */
	public float getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(float price) {
		this.price = price;
	}

	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the isDeleted
	 */
	public boolean isDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the offer
	 */
	public int getOffer() {
		return offer;
	}

	/**
	 * @param offer the offer to set
	 */
	public void setOffer(int offer) {
		this.offer = offer;
	}

	
}
