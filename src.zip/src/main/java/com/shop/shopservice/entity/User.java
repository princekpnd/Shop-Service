package com.shop.shopservice.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.shop.shopservice.utils.PrePersistUtil;

/**
 * @author Avinash
 *
 */

@Entity
@Table(name = "USER")
@NamedQueries({
    @NamedQuery(name="User.findAll",
                query="SELECT u FROM User u"),
    @NamedQuery(name="User.findByMobile",
    			query="SELECT u FROM User u WHERE u.mobileNo = :mobileNo"),
    @NamedQuery(name="User.validatePwd",
                query="SELECT u FROM User u WHERE u.emailId = :email or u.mobileNo = :email and u.pwd = :pwd and u.isActive is TRUE and u.isDeleted is FALSE"),
    @NamedQuery(name="User.findByOtp",
    		  query="SELECT u FROM User u WHERE u.mobileNo = :mobileNo and u.otp = :otp"),
    @NamedQuery(name="User.findOtpByMobileNumber",
	           query="SELECT u FROM User u WHERE u.mobileNo = :mobileNo"),
   
}) 
public class User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1385794955661915701L;
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false)
	private int userId;
	
	@Column(name = "EMAIL_ID", nullable = false)
	private String emailId;
	
	@Column(name = "F_NAME", nullable = false)
	private String firstName;
	
	@Column(name = "L_NAME", nullable = false)
	private String lastName;
	
	@Column(name = "Last_Login_Date")
	private Date lastLoginDate;
	
	@Column(name = "USER_TYPE", nullable = false)
	private int userType;

	@Column(name = "DOB")
	private Date dob;

	@Column(name = "NAME", nullable = false)
	private String name;

	@Column(name = "BIOGRAPHY", nullable = true)
	private String biography;
	
	@Column(name = "WISH_LIST", nullable = true)
	private String wishList;

	@Column(name = "INITIALS", nullable = true)
	private String initials;

	@Transient
	private String displayName;
	
	@Column(name = "CREATED_ON")
	private Date createdOn;

//	@Column(name = "USER_TYPE", nullable = true)
//	private int userType;
//
//	@Column(name = "MO_ID", nullable = false)
//	private int managementObject;
//	
//	@Column(name = "WALLET_BALANCE", nullable = true)
//	private int walletBalance;
//
//	@Column(name = "BANK_DETAILS", nullable = true)
//	private int bankDetails;
	
//	@Column(name = "ADDRESS_DETAILS", nullable = true)
//	private int address;
	
	@Column(name = "ARTICLE_DETAILS", nullable = true)
	private int article;
	
	@Column(name = "MOBILE_NUMBER", nullable = true)
	private String mobileNo;
	
	@Column(name = "TOKEN", nullable = true)
	private String token;
	
	@Column(name = "OTP", nullable = true)
	private String otp;
//	
//	@Column(name = "FOLLOW_COUNT", nullable = false)
//	private int followCount;
	
//	@Column(name = "FOLLOWING", nullable = true)
//	private String following;
	
//	@Column(name = "FOLLOWING_COUNT", nullable = false)
//	private int followingCount;
	
	@Column(name = "CITY", nullable = true)
	private String city;
	
//	@Transient
//	private ArrayList<User> assistants;

	// @Type(type="yes_no")
	@Column(name = "ACTIVE_IND", nullable = false)
	private boolean isActive;
	
	@Column(name = "PWD", nullable = false)
	private String pwd;
	
	@Column(name = "IS_DELETED", nullable = false)
	private boolean isDeleted;
	
	@OneToMany(mappedBy="user",cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private List<UserDeviceID> userDeviceIDList;
	
	@OneToMany(mappedBy="user",cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private List<Address> address;
	
	/**
	 * @return the userDeviceIDList
	 */
	public List<UserDeviceID> getUserDeviceIDList() {
		return userDeviceIDList;
	}

	/**
	 * @param userDeviceIDList the userDeviceIDList to set
	 */
	public void setUserDeviceIDList(List<UserDeviceID> userDeviceIDList) {
		this.userDeviceIDList = userDeviceIDList;
	}
	
	

	/**
	 * @return the address
	 */
	public List<Address> getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(List<Address> address) {
		this.address = address;
	}



	public int getUserId() {
		return userId;
	}

	public User() {
		super();
	}

	public User(String mobileNo, String name) {
		this.mobileNo = mobileNo;
		this.name = name;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	




	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(Date lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	
	/**
	 * @return the userType
	 */
	public int getUserType() {
		return userType;
	}

	/**
	 * @param userType the userType to set
	 */
	public void setUserType(int userType) {
		this.userType = userType;
	}

	public String getInitials() {
		return initials;
	}

	public void setInitials(String initials) {
		this.initials = initials;
	}

	public String getDisplayName() {
		return name;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	/**
	 * @return the userType
	 */

//	/**
//	 * @return the address
//	 */
//	public int getAddress() {
//		return address;
//	}
//
//	/**
//	 * @param address the address to set
//	 */
//	public void setAddress(int address) {
//		this.address = address;
//	}

	/**
	 * @return the article
	 */
	public int getArticle() {
		return article;
	}

	/**
	 * @param article the article to set
	 */
	public void setArticle(int article) {
		this.article = article;
	}



	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * @return the isDeleted
	 */
	public boolean isDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the biography
	 */
	public String getBiography() {
		return biography;
	}

	/**
	 * @param biography the biography to set
	 */
	public void setBiography(String biography) {
		this.biography = biography;
	}
	

	/**
	 * @return the wishList
	 */
	public String getWishList() {
		return wishList;
	}

	/**
	 * @param wishList the wishList to set
	 */
	public void setWishList(String wishList) {
		this.wishList = wishList;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the otp
	 */
	public String getOtp() {
		return otp;
	}

	/**
	 * @param otp the otp to set
	 */
	public void setOtp(String otp) {
		this.otp = otp;
	}
	
	@PrePersist
    void preInsert() {
       PrePersistUtil.pre(this);
    }
}
