package com.shop.shopservice.entity;

import javax.persistence.Column;
import javax.persistence.Id;

/**
 * @author Avinash
 *
 */
public class UserAddress {

	@Id
	@Column(name = "USER_ADDRESS_ID", nullable = false)
	private String UserAddressId;

	@Id
	@Column(name = "USER_ID", nullable = false)
	private String UserId;
}
