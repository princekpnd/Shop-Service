package com.shop.shopservice.daoImpl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shop.shopservice.Idao.INotificationDAO;
import com.shop.shopservice.entity.Notification;
import com.shop.shopservice.entity.User;
import com.shop.shopservice.service.IUserService;


@Repository
@Transactional
public class NotificationDAOImpl implements INotificationDAO {

	@PersistenceContext	
	private EntityManager entityManager;

	
	@Override
	public List<Notification> getAllNotification(int count) {
		return entityManager.createNamedQuery("Notification.findAll", Notification.class).setMaxResults(count).getResultList();
	}

	@Override
	public Notification getNotificationById(long notificationId) {
		Notification notification =  this.entityManager.find(Notification.class, notificationId);
		return notification;
	}

	@Override
	public void createNotification(Notification notification) {
		notification.setCreatedOn(new Date());
		entityManager.persist(notification);

	}

	@Override
	public void updateNotification(Notification notification) {
	entityManager.merge(notification);
	}

	
	@Override
	public List<Notification> getNotificationByUserId(int userId) {
			return (List<Notification>)entityManager.createNamedQuery("Notification.findByUserId",Notification.class).setParameter("userId", userId).getResultList();
	}

	@Override
	public List<Notification> getAllNotificationOnCatagory(int catagory) {
		return (List<Notification>)entityManager.createNamedQuery("Notification.findByCatagory",Notification.class).setParameter("catagoryId", catagory).getResultList();
	}

	@Override
	public List<Notification> getAllNotificationOnSubCatagory(List<Integer> subCatagoryList) {
		// TODO Auto-generated method stub
		return null;
	}


}
