package com.shop.shopservice.daoImpl;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.shop.shopservice.Idao.IProductDAO;
import com.shop.shopservice.entity.Employee;
import com.shop.shopservice.entity.Product;

@Repository
@Transactional
public class ProductDAOImpl implements IProductDAO{
	
	@PersistenceContext	
	private EntityManager entityManager;
	
	@Override
	public List<Product> getAllProduct() {
		List<Product> productList= entityManager.createNamedQuery("Product.findAll", Product.class).getResultList();
		return productList;
	}
	
	@Override
	public List<Product> getAllProductForUser() {
		List<Product> productList= entityManager.createNamedQuery("Product.findAllForUser", Product.class).getResultList();
		return productList;
	}
	
	@Override
	public Product getProductById(int productId) {
		return this.entityManager.find(Product.class, productId);
	}
	
	@Override
	public List<Product> getProductByName(String name) {
		List<Product> productList= entityManager.createNamedQuery("Product.findByName", Product.class).setParameter("name", name).getResultList();
		return productList;
	}
	
	@Override
	public Product getProductByCategory(int category) {
		Product product= entityManager.createNamedQuery("Product.findByCategory",Product.class).setParameter("category", category).getSingleResult();
		return product;
	}
	
	@Override
	public List<Product> getProductByShopIdForCategory(String shopId, int category) {
		List<Product> productList =entityManager.createNamedQuery("Product.findProductByShopIdForCategory",Product.class).setParameter("shopId",shopId).setParameter("category", category).getResultList();
		return productList;
	}

	
	@Override
	public List<Product> getProductByShopId(String shopId) {
		List<Product> productList= entityManager.createNamedQuery("Product.findByShopId", Product.class).setParameter("shopId", shopId).getResultList();
		return productList;
	}
	@Override
	public List<Product> getProductForUserByShopId(String shopId) {
		List<Product> productList =entityManager.createNamedQuery("Product.findProductByShopId", Product.class).setParameter("shopId",shopId).getResultList();
		return productList;
	}
	
	@Override
	public List<Product> getProductByBrandName(int brand) {
		List<Product> product = entityManager.createNamedQuery("Product.findProductByBrand", Product.class).setParameter("brand", brand).getResultList();
		return product;
	}
	
	@Override
	public void updateProduct(Product product) {
	entityManager.merge(product);
	}
	
	@Override
	public boolean productExists(String shopId) {
		Product product = entityManager.createNamedQuery("Product.findByShopId",Product.class).setParameter("shopId", shopId).getResultList().stream().findFirst().orElse(null);;
		return null != product ?Boolean.TRUE:Boolean.FALSE;
	}
	
	@Override
	public void addProduct(Product product) {
		entityManager.persist(product);
	}

	
	
}
