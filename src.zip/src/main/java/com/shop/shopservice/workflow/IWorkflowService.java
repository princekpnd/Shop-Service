package com.shop.shopservice.workflow;

public class IWorkflowService {

}
