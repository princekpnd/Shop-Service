package com.shop.shopservice.socialmedia;

/**
 * @author Avinash
 *
 */
public interface IArticleSocialMedia {

}
