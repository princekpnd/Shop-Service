package com.shop.shopservice.dto;

/**
 * @author Avinash
 *
 */
public class PaymentGatewayDTO {

}
