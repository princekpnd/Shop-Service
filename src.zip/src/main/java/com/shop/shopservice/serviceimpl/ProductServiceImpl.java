package com.shop.shopservice.serviceimpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.shop.shopservice.Idao.IProductDAO;
import com.shop.shopservice.entity.Product;
import com.shop.shopservice.service.IProductService;

@Transactional
@Repository


public class ProductServiceImpl implements IProductService{
	
	@Autowired
	IProductDAO productDao;
	

	@Override
	public List<Product> getAllProduct() {
		return productDao.getAllProduct();
	}
	
	@Override
	public List<Product> getAllProductForUser() {
		return productDao.getAllProductForUser();
	}

	@Override
	public Product getProduct(int productId) {
		return productDao.getProductById(productId);
	}
	
	@Override
	public List<Product> getProductByName(String name) {
		return productDao.getProductByName(name);
	}
	@Override
	public Product getProductByCategory(int category) {
		return productDao.getProductByCategory(category);
	}
	
	@Override
	public List<Product> getProductByShopId(String shopId) {
		return productDao.getProductByShopId(shopId);
	}
	@Override
	public List<Product> getProductForUserByShopId(String shopId) {
		return productDao.getProductForUserByShopId(shopId);
	}

	@Override
	public List<Product> getProductByBrandName(int brand) {
		return productDao.getProductByBrandName(brand);
	}
	
	@Override
	public boolean updateProduct(Product product) {
		productDao.updateProduct(product);
		return true;
	}
	
	@Override
	public boolean productExists(String shopId) {
		return productDao.productExists(shopId);
	}
	
	public boolean createProduct(Product product) {

		if (productExists(product.getShopId())) {
			return false;
		} else {
			productDao.addProduct(product);			
			return true;
		}
	}

	@Override
	public List<Product> getProductByShopIdForCategory(String shopId, int category) {
		return productDao.getProductByShopIdForCategory(shopId,category) ;
	}

	
}
