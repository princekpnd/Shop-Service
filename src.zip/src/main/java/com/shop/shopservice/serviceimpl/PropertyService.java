package com.shop.shopservice.serviceimpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shop.shopservice.Idao.ILookUp;
import com.shop.shopservice.Idao.ILookUpType;
import com.shop.shopservice.entity.LookUp;
import com.shop.shopservice.entity.LookUpType;
import com.shop.shopservice.utils.PropertyBundle;


public class PropertyService {

	
	
	
	
}
