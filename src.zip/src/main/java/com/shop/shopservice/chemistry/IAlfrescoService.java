package com.shop.shopservice.chemistry;

/**
 * @author Avinash
 *
 */
public interface IAlfrescoService {

}
