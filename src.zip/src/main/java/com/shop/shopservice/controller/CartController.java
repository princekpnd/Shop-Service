package com.shop.shopservice.controller;

import java.net.URISyntaxException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.shop.shopservice.constants.ServiceConstants;
import com.shop.shopservice.entity.Admin;
import com.shop.shopservice.entity.Cart;
import com.shop.shopservice.entity.Product;
import com.shop.shopservice.entity.ProductList;
import com.shop.shopservice.service.IAdminService;
import com.shop.shopservice.service.ICartService;
import com.shop.shopservice.service.IProductService;

@RestController
@RequestMapping("/api/cart")
public class CartController {
	private final Logger log = LoggerFactory.getLogger(CartController.class);
	@Autowired
	ICartService cartService;

	@Autowired
	private IProductService productService;

	@Autowired
	private IAdminService adminService;

	@GetMapping("getallcart")
	public ResponseEntity<List<Cart>> getAllCart() {
		List<Cart> cartList = cartService.getAllCart();
		return new ResponseEntity<List<Cart>>(cartList, HttpStatus.OK);
	}

	@GetMapping("get/{cartId}")
	public ResponseEntity<Cart> getCartById(@PathVariable("cartId") Integer cartId) {
		Cart cart = cartService.getCart(cartId.intValue());
		return new ResponseEntity<Cart>(cart, HttpStatus.OK);
	}

	@GetMapping("getcartbyuserid/{userId}/{shopId}")
	public ResponseEntity<List<Cart>> getCartByUserId(@PathVariable("userId") String userId,
			@PathVariable("shopId") String shopId) {
		List<Cart> cart = cartService.getCartByUserId(userId, shopId, Boolean.TRUE);
		return new ResponseEntity<List<Cart>>(cart, HttpStatus.OK);
	}

	@GetMapping("getcartforuserbyshopid/{shopId}")
	public ResponseEntity<List<Cart>> getCartForUserByShopId(@PathVariable("shopId") String shopId) {
		Admin admin = adminService.getAdminByShopId(shopId);
		List<Cart> cartList = null;
		if (admin != null && admin.isActive() == Boolean.TRUE && admin.isDeleted() == Boolean.FALSE) {
			cartList = cartService.getCartForUserByShopId(shopId);
		}
		return new ResponseEntity<List<Cart>>(cartList, HttpStatus.OK);
	}

	@PutMapping("/update")
	ResponseEntity<Map<String, String>> UpdateCart(@Valid @RequestBody Map<String, String> json,
			HttpServletRequest request) throws URISyntaxException {
		log.info("Request to update user: {}", json.get(ServiceConstants.NAME));
		Map<String, String> response = new HashMap<String, String>();
		if (null != json.get(ServiceConstants.ID)
				&& null != cartService.getCart(Integer.parseInt(json.get(ServiceConstants.ID)))) {
			Cart cart = cartService.getCart(Integer.parseInt(json.get(ServiceConstants.ID)));

			if (null != json.get(ServiceConstants.ID)) {
				int id = Integer.parseInt(json.get(ServiceConstants.ID).toString());
				cart.setCartId(id);
			}

			if (null != json.get(ServiceConstants.SHOP_ID)) {
				String shopId = json.get(ServiceConstants.SHOP_ID).toString();
				cart.setShopId(shopId);
			}

			if (null != json.get(ServiceConstants.USER_ID)) {
				String userId = json.get(ServiceConstants.USER_ID).toString();
				cart.setUserId(userId);
			}

			if (null != json.get(ServiceConstants.CREATED_ON)) {
				Date createdOn = new Date();
				cart.setCreatedOn(createdOn);
			}

			if (null != json.get(ServiceConstants.GST_AMOUNT)) {
				Float gstAmount = Float.parseFloat((json.get(ServiceConstants.GST_AMOUNT).toString()));
				cart.setGstAmount(gstAmount);
			}

			if (null != json.get(ServiceConstants.TOTAL_AMOUNT)) {
				Float totalAmount = Float.parseFloat((json.get(ServiceConstants.TOTAL_AMOUNT).toString()));
				cart.setTotalAmount(totalAmount);
			}

			if (null != json.get(ServiceConstants.TRANSACTION_ID)) {
				String transactionId = json.get(ServiceConstants.TRANSACTION_ID).toString();
				cart.setTransactionId(transactionId);
			}

			if (null != json.get(ServiceConstants.DUES)) {
				float dues = Float.parseFloat((json.get(ServiceConstants.DUES).toString()));
				cart.setDues(dues);
			}
			if (null != json.get(ServiceConstants.PAID)) {
				float paid = Float.parseFloat((json.get(ServiceConstants.PAID).toString()));
				cart.setPaid(paid);
			}

			if (null != json.get(ServiceConstants.IS_ACTIVE)) {
				boolean isActive = Boolean.parseBoolean((json.get(ServiceConstants.IS_ACTIVE).toString()));
				cart.setActive(isActive);
			}

			if (null != json.get(ServiceConstants.IS_DELETED)) {
				boolean isDeleted = Boolean.parseBoolean((json.get(ServiceConstants.IS_DELETED).toString()));
				cart.setDeleted(isDeleted);
			}

			if (null != json.get(ServiceConstants.ORDER)) {
				boolean order = Boolean.parseBoolean((json.get(ServiceConstants.ORDER).toString()));
				cart.setOrderStatus(order);
			}

			cartService.updateCart(cart);
			response.put("status", Boolean.TRUE.toString());
			response.put("description", "Cart updated");
		} else {
			response.put("status", Boolean.FALSE.toString());
			response.put("description", "Cart doesn't exist with given  userid");
		}
		return ResponseEntity.ok().body(response);
	}

	@SuppressWarnings({})
	@PostMapping("/addproduct")
	ResponseEntity<Map<String, List<Cart>>> createCart(@Valid @RequestBody Map<String, String> json,
			HttpServletRequest request) throws URISyntaxException {
		log.info("Request to create user: {}", json.get(ServiceConstants.USER_ID));
		Map<String, List<Cart>> response = new HashMap<String, List<Cart>>();
		if (null != json.get(ServiceConstants.USER_ID) && null != json.get(ServiceConstants.SHOP_ID)
				&& null != json.get(ServiceConstants.PRODUCT_ID)
				&& null != json.get(ServiceConstants.PRODUCT_QUANTITY)) {

			List<Cart> cartList = null;
			Cart cart = null;
			List<ProductList> productList = null;
			ProductList cartProduct = null;

			String userId = json.get(ServiceConstants.USER_ID), shopId = json.get(ServiceConstants.SHOP_ID),
					productId = json.get(ServiceConstants.PRODUCT_ID);
			float productQuantity = Float.parseFloat(json.get(ServiceConstants.PRODUCT_QUANTITY));

			Product product = productService.getProduct(Integer.parseInt(productId));

			boolean result = cartService.cartExists(userId, shopId, Boolean.TRUE);

			if (result) {
				cartList = cartService.getCartByUserId(userId, shopId, Boolean.TRUE);
				cart = cartList.get(0);
				float totalAmount = product.getPrice() * productQuantity, gstAmount = 15;

				cart.setTotalAmount(cart.getTotalAmount() + totalAmount);
				cart.setGstAmount(cart.getGstAmount() + gstAmount);
				productList = cart.getProductList();

				cartProduct = cartService.getProductByProductId(productId, cart.getCartId());

				if (null != cartProduct) {
					cartProduct.setProductQuantity(productQuantity);
					cartService.updateProductList(cartProduct, productQuantity);
				} else {
					cartProduct = new ProductList();

					cartProduct.setShopId(shopId);
					cartProduct.setActive(Boolean.TRUE);
					cartProduct.setDeleted(Boolean.FALSE);
					cartProduct.setCart(cart);
					cartProduct.setCreatedOn(new Date());
					cartProduct.setPrice(product.getPrice());
					cartProduct.setProductId(productId);
					cartProduct.setProductName(product.getName());
					cartProduct.setProductQuantity(productQuantity);
					cartProduct.setOffer(product.getOfferPercent());
					cartProduct.setUserId(userId);

					cart.getProductList().add(cartProduct);
				}

//				for (int i = 0; i < productList.size(); i++) {
//					if (productId == productList.get(i).getProductId()) {
////						cartProduct = productList.get(i);
////						cartProduct.setProductQuantity(productQuantity);	
//
//						cart.getProductList().get(i).setProductQuantity(productQuantity);
//					}
//				}

				boolean finalResult = cartService.updateCart(cart);
				response.put("" + finalResult, cartList);
			} else {
				cart = new Cart(userId, shopId);
				cartProduct = new ProductList();
				float totalAmount = product.getPrice() * productQuantity, gstAmount = 15;

				cart.setTotalAmount(totalAmount);
				cart.setGstAmount(gstAmount);
				cart.setActive(Boolean.TRUE);
				cart.setDeleted(Boolean.FALSE);
				cart.setCreatedOn(new Date());
				cart.setOrderStatus(Boolean.TRUE);
				cart.setDues(totalAmount);
				cart.setPaid(0);
				cart.setShopId(shopId);
				cart.setUserId(userId);

				cartProduct.setCart(cart);
				cartProduct.setActive(Boolean.TRUE);
				cartProduct.setCreatedOn(new Date());
				cartProduct.setDeleted(Boolean.FALSE);
				cartProduct.setPrice(product.getPrice());
				cartProduct.setProductId(productId);
				cartProduct.setProductName(product.getName());
				cartProduct.setProductQuantity(productQuantity);
				cartProduct.setOffer(product.getOfferPercent());
				cartProduct.setShopId(shopId);
				cartProduct.setUserId(userId);

				cart.getProductList().add(cartProduct);

				boolean finalResult = cartService.createCart(cart);
				cartList = cartService.getCartByUserId(userId, shopId, Boolean.TRUE);

				response.put("" + finalResult, cartList);
			}
		}
//		Cart cart = new Cart(json.get(ServiceConstants.USER_ID), json.get(ServiceConstants.SHOP_ID));
//
//		cart.setUserId(json.get(ServiceConstants.USER_ID));
//		cart.setCreatedOn(new Date());
//		cart.setShopId(json.get(ServiceConstants.SHOP_ID));
//		cart.setTransactionId(json.get(ServiceConstants.TRANSACTION_ID));
//		cart.setGstAmount(Float.parseFloat(json.get(ServiceConstants.GST_AMOUNT)));
//		cart.setTotalAmount(Float.parseFloat(json.get(ServiceConstants.TOTAL_AMOUNT)));
//		cart.setPaid(Float.parseFloat(json.get(ServiceConstants.PAID)));
//		cart.setDues(Float.parseFloat(json.get(ServiceConstants.DUES)));
//		cart.setActive(Boolean.TRUE);
//		cart.setDeleted(Boolean.FALSE);
//		cart.setOrderStatus(Boolean.TRUE);

//		if (cartService.cartExists(cart.getUserId())) {
//			response.put("status", Boolean.FALSE.toString());
//			response.put("description", "Cart already exist with given User Id");
//		} else {
//		boolean result = cartService.createCart(cart);
//		response.put("status", Strings.EMPTY + result);
//		response.put("description", "Cart created successfully with given account, go through your inbox to activate");
//		}
		return ResponseEntity.ok().body(response);
	}

}
