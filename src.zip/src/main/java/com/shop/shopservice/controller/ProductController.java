   package com.shop.shopservice.controller;

import java.net.URISyntaxException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.shop.shopservice.Idao.ILookUp;
import com.shop.shopservice.constants.ServiceConstants;
import com.shop.shopservice.entity.Admin;
import com.shop.shopservice.entity.LookUp;
import com.shop.shopservice.entity.Product;
import com.shop.shopservice.service.IAdminService;
import com.shop.shopservice.service.IProductService;

@RestController
@RequestMapping("/api/product")

public class ProductController {
	
	private final Logger log = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private IProductService productService;
	
	@Autowired
	private ILookUp lookup;
	
	@Autowired
	private IAdminService adminService;
	
	@GetMapping("getallproduct")
	public ResponseEntity<List<Product>> getAllProduct() {
		List<Product> productList = productService.getAllProduct();
		return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);
	}
	
	@GetMapping("getallproductforuser")
	public ResponseEntity<List<Product>> getAllProductForUser() {
		List<Product> productList = productService.getAllProductForUser();
		return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);
	}
	
	@GetMapping("get/{productId}")
	public ResponseEntity<Product> getProductById(@PathVariable("productId") Integer productId) {
		Product product = productService.getProduct(productId.intValue());
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}

	@GetMapping("getproductbyname/{name}")
	public ResponseEntity<List<Product>> getProductByName(@PathVariable("name") String name) {
		List<Product> productList = productService.getProductByName(name);
		return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);
	}
	
	@GetMapping("getproductbycategory/{category}")
	public ResponseEntity<Product> getProductByCategory(@PathVariable("category") Integer category) {
		Product product = productService.getProductByCategory(category.intValue());
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	@GetMapping("getproductbyshopidandcategory/{shopId}/{category}")
	public ResponseEntity<List<Product>> getProductByShopIdForCategory(@PathVariable("shopId") String shopId ,@PathVariable("category") Integer category){
		List<Product> productList =productService.getProductByShopIdForCategory(shopId ,category.intValue());
		return new ResponseEntity<List<Product>>(productList,HttpStatus.OK);
	}

	@GetMapping("getproductbyshopid/{shopId}")
	public ResponseEntity<List<Product>> getProductByShopId(@PathVariable("shopId") String shopId) {
		Admin admin =adminService.getAdminByShopId(shopId);
		List<Product> productList =null;
		if(admin != null && admin.isActive()== Boolean.TRUE && admin.isDeleted()== Boolean.FALSE) {
		 productList = productService.getProductByShopId(shopId);
		}
		return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);
	}
	
	@GetMapping("getproductforuserbyshopId/{shopId}")
	public ResponseEntity<List<Product>> getProductForUserByShopId(@PathVariable("shopId") String shopId){
		Admin admin = adminService.getAdminByShopId(shopId);
		List<Product> productList =null;
		if(admin !=null && admin.isActive()== Boolean.TRUE && admin.isDeleted()==Boolean.FALSE) {
		 productList = productService.getProductForUserByShopId(shopId);
		}
		return new ResponseEntity<List<Product>>(productList,HttpStatus.OK);
	}
	
	@GetMapping("getproductbybrandname/{shopId}/{brandName}")
	public ResponseEntity<List<Product>> getProductByBrand(@PathVariable("shopId") String shopId, @PathVariable("brandName") String brand) {
		int lookUpId = lookup.findLookUpIdByName(shopId, brand).getLookUpId();
		List<Product> productList = productService.getProductByBrandName(lookUpId);
		return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);
	}
	
	
	
	@PutMapping("/update")
	ResponseEntity<Map<String, String>> UpdateCart(@Valid @RequestBody Map<String, String> json,
			HttpServletRequest request) throws URISyntaxException {
		log.info("Request to update user: {}", json.get(ServiceConstants.NAME));
		Map<String, String> response = new HashMap<String, String>();
		if (null != json.get(ServiceConstants.ID) && null != productService.getProduct(Integer.parseInt(json.get(ServiceConstants.ID)))) {
			Product product = productService.getProduct(Integer.parseInt(json.get(ServiceConstants.ID)));
			
			if(null != json.get(ServiceConstants.ID)) {
				int productId =Integer.parseInt( json.get(ServiceConstants.ID).toString());
				product.setProductId(productId);				
				}
			

			if(null != json.get(ServiceConstants.NAME)) {
				String name = json.get(ServiceConstants.NAME).toString();
				product.setName(name);				
				}
			
			
			
			if(null != json.get(ServiceConstants.CATEGORY)) {
			  int category =Integer.parseInt( json.get(ServiceConstants.CATEGORY).toString());
				product.setCategory(category);				
				}

			
			if(null != json.get(ServiceConstants.BRAND )) {
				int brand =Integer.parseInt( json.get(ServiceConstants.BRAND ).toString());
				product.setBrand(brand);				
			}
			
			
			if(null != json.get(ServiceConstants.SHOP_ID)) {
				String shopId = json.get(ServiceConstants.SHOP_ID).toString();
				product.setShopId(shopId);				
				}
			

			if(null != json.get(ServiceConstants.AVATAR)) {
				String avtar = json.get(ServiceConstants.AVATAR).toString();
				product.setAvatar(avtar);				
				}
			
			if(null != json.get(ServiceConstants.PRICE)) {
				float price =Float.parseFloat( json.get(ServiceConstants.PRICE).toString());
				product.setPrice(price);				
				}
			
			if(null != json.get(ServiceConstants.QUANTITY)) {
				int quantity =Integer.parseInt( json.get(ServiceConstants.QUANTITY).toString());
				product.setQuantity(quantity);				
				}
			
			if(null != json.get(ServiceConstants.REVIEW)) {
				String review = json.get(ServiceConstants.REVIEW).toString();
				product.setReview(review);				
				}
			
			if(null != json.get(ServiceConstants.DISCREPTION)) {
				String discreption = json.get(ServiceConstants.DISCREPTION).toString();
				product.setDiscreption(discreption);				
				}
			
			if(null != json.get(ServiceConstants.IS_ACTIVE)) {
				boolean isActive =Boolean.parseBoolean(( json.get(ServiceConstants.IS_ACTIVE).toString()));
				product.setActive(isActive);				
				}
			

			if(null != json.get(ServiceConstants.IS_DELETED)) {
				boolean isDeleted =Boolean.parseBoolean( json.get(ServiceConstants.IS_DELETED).toString());
				product.setDeleted(isDeleted);				
				}
			
			if(null != json.get(ServiceConstants.BARCOADE)) {
				String barcoade =json.get(ServiceConstants.BARCOADE).toString();
				product.setBarcoade(barcoade);	
				
				}
			if(null != json.get(ServiceConstants.STOCK)) {
				int stock =Integer.parseInt(json.get(ServiceConstants.STOCK).toString());
				product.setStock(stock);	
				
				}
			if(null !=json.get(ServiceConstants.COST_PRICE)) {
				float costPrice =(Float.parseFloat(json.get(ServiceConstants.COST_PRICE).toString()));
				product.setCostPrice(costPrice);
			}
			if(null != json.get(ServiceConstants.SALE_PRICE)) {
				float salePrice =Float.parseFloat(json.get(ServiceConstants.SALE_PRICE).toString());
				product.setSalePrice(salePrice);
			}
			if(null != json.get(ServiceConstants.OFFER_PERCENT)) {
				int offerPercent =Integer.parseInt(json.get(ServiceConstants.OFFER_PERCENT).toString());
				product.setOfferPercent(offerPercent);
			}
			if(null != json.get(ServiceConstants.OLD_PRICE)) {
				float oldPrice = Float.parseFloat(json.get(ServiceConstants.OLD_PRICE).toString());
				product.setOldPrice(oldPrice);
			}
			if( null!= json.get(ServiceConstants.OFFER_FROM)) {
				Date offerFrom = new Date();
				product.setOfferFrom(offerFrom);
			}
			if(null !=json.get( ServiceConstants.OFFER_LAST)) {
				Date offerFrom =new Date();
				product.setOfferFrom(offerFrom);
			}
			if(null != json.get(ServiceConstants.OFFER_ACTIVE_END)) {
				boolean offerActiveEnd  = Boolean.parseBoolean(json.get(ServiceConstants.OFFER_ACTIVE_END).toString());
				product.setOfferActiveEnd(offerActiveEnd);
			}
			
		
			productService.updateProduct(product);
			response.put("status", Boolean.TRUE.toString());
			response.put("description", "Product updated");
		}
		else {
			response.put("status", Boolean.FALSE.toString());
			response.put("description",
					"Product doesn't exist with given  userid");
		}
		return ResponseEntity.ok().body(response);
			}
	
	@SuppressWarnings({ })
	@PostMapping("/create")
	ResponseEntity<Map<String, String>> createProduct(@Valid @RequestBody Map<String, String> json,
			HttpServletRequest request) throws URISyntaxException {
		log.info("Request to create user: {}", json.get(ServiceConstants.SHOP_ID));
		Map<String, String> response = new HashMap<String, String>();
		Product product = new Product(Integer.parseInt(json.get(ServiceConstants.BRAND)), json.get(ServiceConstants.SHOP_ID));
		
		
		product.setName(json.get(ServiceConstants.NAME));
		product.setCategory(Integer.parseInt(json.get(ServiceConstants.CATEGORY )));
		product.setBrand(Integer.parseInt(json.get(ServiceConstants.BRAND )));
		product.setShopId(json.get(ServiceConstants.SHOP_ID ));
		product.setAvatar(json.get(ServiceConstants.AVATAR ));
		product.setPrice(Float.parseFloat(json.get(ServiceConstants.PRICE )));
		product.setQuantity(Integer.parseInt((json.get(ServiceConstants.QUANTITY ))));
		product.setReview(json.get(ServiceConstants.REVIEW ));
		product.setDiscreption(json.get(ServiceConstants.DISCREPTION));
		product.setActive(Boolean.parseBoolean(json.get(ServiceConstants.IS_ACTIVE)));
		product.setDeleted(Boolean.parseBoolean(json.get(ServiceConstants.IS_DELETED)));
		product.setBarcoade(json.get(ServiceConstants.BARCOADE ));
		product.setStock(Integer.parseInt( json.get(ServiceConstants.STOCK )));
		product.setSalePrice(Float.parseFloat(json.get(ServiceConstants.SALE_PRICE)));
		product.setCostPrice(Float.parseFloat(json.get(ServiceConstants.COST_PRICE)));
		product.setOldPrice(Float.parseFloat(json.get(ServiceConstants.OLD_PRICE)));
		product.setOfferPercent(Integer.parseInt(json.get(ServiceConstants.OFFER_PERCENT)));
		product.setOfferFrom(new Date());
		product.setOfferLast(new Date());
		product.setOfferActiveEnd(Boolean.parseBoolean(json.get(ServiceConstants.OFFER_ACTIVE_END)));
		
		
		
		response.put("shopId", json.get(ServiceConstants.SHOP_ID));
		if (productService.productExists(product.getShopId())) {
			response.put("status", Boolean.FALSE.toString());
			response.put("description", "Product already exist with given Shop Id");
		} else {
			boolean result = productService.createProduct(product);
			response.put("status", Strings.EMPTY + result);
			response.put("description",
					"Product created successfully with given Shop Id , go through your inbox to activate");
		}
		return ResponseEntity.ok().body(response);
	}

}
 