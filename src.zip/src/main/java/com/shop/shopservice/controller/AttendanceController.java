package com.shop.shopservice.controller;

import java.net.URISyntaxException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.shop.shopservice.constants.ServiceConstants;
import com.shop.shopservice.entity.Admin;
import com.shop.shopservice.entity.Attendance;
import com.shop.shopservice.service.IAdminService;
import com.shop.shopservice.service.IAttendanceService;
@RestController
@RequestMapping("/api/attendance")

public class AttendanceController {
	@Autowired
	private IAttendanceService attendanceService;
	
	@Autowired
	private IAdminService adminService;
	
	private final Logger log = LoggerFactory.getLogger(AttendanceController.class);
	
	@GetMapping("getallattendance")
	public ResponseEntity<List<Attendance>> getAllattendance() {
		List<Attendance> attendanceList = attendanceService.getAllAttendance();
		return new ResponseEntity<List<Attendance>>(attendanceList, HttpStatus.OK);
	}
	
	@GetMapping("get/{employeeId}")
	public ResponseEntity<List<Attendance>> getAttendanceByEmployeeId(@PathVariable("employeeId") String employeeId) {
		List<Attendance> attendance = attendanceService.getByEmployeeId(employeeId);
		return new ResponseEntity<List<Attendance>>(attendance, HttpStatus.OK);
	}
	
	@GetMapping("getbyshopid/{shopId}")
	public ResponseEntity<List<Attendance>> getAttendanceByShopId(@PathVariable("shopId") String shopId){
		Admin admin =adminService.getAdminByShopId(shopId);
		List<Attendance> attendanceList = null;
		if(admin !=null  &&admin.isActive()==Boolean.TRUE && admin.isDeleted()==Boolean.FALSE) {
			
			attendanceList = attendanceService.getByShopId(shopId);
		}
				return new ResponseEntity<List<Attendance>>(attendanceList, HttpStatus.OK);
	}
	
	
	@SuppressWarnings({ })
	@PostMapping("/create")
	ResponseEntity<Map<String, String>> createAttendance(@Valid @RequestBody Map<String, String> json,
			HttpServletRequest request) throws URISyntaxException {
		log.info("Request to create user: {}", json.get(ServiceConstants.EMPLOYEE_ID));
		Map<String, String> response = new HashMap<String, String>();
		Attendance attendance = new Attendance(json.get(ServiceConstants.EMPLOYEE_ID),(json.get(ServiceConstants.SHOP_ID)));
		
		attendance. setEmployeeId(json.get(ServiceConstants.EMPLOYEE_ID));
		attendance. setShopId(json.get(ServiceConstants.SHOP_ID));
//		attendance. setCreatedOn(new Date(json.get(ServiceConstants.CREATED_ON)));
		attendance.  setAttendance(Integer.parseInt(json.get(ServiceConstants.ATTENDANCE)));
		
		response.put("employeeId", json.get(ServiceConstants.EMPLOYEE_ID));
		if (attendanceService.attendanceExists(attendance.getEmployeeId())) {
			response.put("status", Boolean.FALSE.toString());
			response.put("description", "Attendance already exist with given employeeId");
		} else {
			boolean result = attendanceService.createAttendance(attendance);
			response.put("status", Strings.EMPTY + result);
			response.put("description",
					"Attendance created successfully with given employeeId, go through your inbox to activate");
		}
		return ResponseEntity.ok().body(response);
	}
	
	
	@PutMapping("/update")
	ResponseEntity<Map<String, String>> UpdateAccount(@Valid @RequestBody Map<String, String> json,
			HttpServletRequest request) throws URISyntaxException {
		log.info("Request to update user: {}", json.get(ServiceConstants.NAME));
		Map<String, String> response = new HashMap<String, String>();
		if (null != json.get(ServiceConstants.EMPLOYEE_ID) && null != attendanceService.getAttendance(json.get(ServiceConstants.EMPLOYEE_ID))) {
			Attendance attendance = attendanceService.getAttendance(json.get(ServiceConstants.EMPLOYEE_ID));
		//	if (null != json.get(ServiceConstants.EMPLOYEE_ID) && null != attendanceService.getAttendance(json.get(ServiceConstants.EMPLOYEE_ID))) {
		//		Attendance Attendance = attendanceService.getAttendance(json.get(ServiceConstants.EMPLOYEE_ID));
				

				if(null != json.get(ServiceConstants.ID)) {
					int id = Integer.parseInt(json.get(ServiceConstants.ID));
					System.out.println(id);
					attendance.setId(id);
					
					}
				

				if(null != json.get(ServiceConstants.EMPLOYEE_ID)) {
					String employeeId = (json.get(ServiceConstants.EMPLOYEE_ID));
					System.out.println(employeeId);
					attendance.setEmployeeId(employeeId);
					
					}
				
				if(null != json.get(ServiceConstants.SHOP_ID)) {
					String shopId = (json.get(ServiceConstants.SHOP_ID));
					System.out.println(shopId);
					attendance.setShopId(shopId);
				}
				
//				if(null !=json.get(ServiceConstants.CREATED_ON)) {
//					Date createdOn =new Date(json.get(ServiceConstants.CREATED_ON).toString());
//					System.out.println(createdOn);
//					attendance.setCreatedOn(createdOn);
//				}
//				
//				if(null != json.get(ServiceConstants.ATTENDANCE)) {
//					int  attendance = Integer.parseInt(json.get(ServiceConstants.ATTENDANCE));
//					System.out.println( attendance);
//					attendance.setAttendance( attendance);
//					
//					}
				
				
				attendanceService.updateAttendance(attendance);
				response.put("status", Boolean.TRUE.toString());
				response.put("description", "Attendance updated");
					}
			else {
				response.put("status", Boolean.FALSE.toString());
				response.put("description",
						"Attendance doesn't exist with given employeeId or userid");
			
			}	
			return ResponseEntity.ok().body(response);
				
			
			
				}

}
