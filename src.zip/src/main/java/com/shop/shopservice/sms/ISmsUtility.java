package com.shop.shopservice.sms;

/**
 * @author Avinash
 *
 */
public interface ISmsUtility {

}
