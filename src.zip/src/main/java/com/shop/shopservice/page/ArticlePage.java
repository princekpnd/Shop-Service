package com.shop.shopservice.page;

/**
 * @author Avinash
 *
 */
public class ArticlePage {

}
