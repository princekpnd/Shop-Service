package com.shop.shopservice.bo;

/**
 * @author Avinash
 *
 */
public interface IPaymentGateway {

}
