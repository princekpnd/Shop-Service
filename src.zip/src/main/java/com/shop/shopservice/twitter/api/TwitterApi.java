package com.shop.shopservice.twitter.api;

public interface TwitterApi {

	public void loginTwitter();
	public void addTwitterTimeLine();
}
