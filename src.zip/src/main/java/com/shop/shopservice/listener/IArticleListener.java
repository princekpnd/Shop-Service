package com.shop.shopservice.listener;

/**
 * @author Avinash
 *
 */
public class IArticleListener {

}
